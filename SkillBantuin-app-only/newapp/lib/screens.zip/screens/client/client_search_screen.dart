import 'package:flutter/material.dart';
import '../../utils/language_notifier.dart';
import '../../widgets/app_theme.dart';
import '../../widgets/app_animations.dart';

/// Filter & Search Screen untuk Client — menampilkan form filter lengkap:
/// search bar, kategori chips, rentang harga + slider, rating minimum,
/// lokasi dropdown, tingkat pengalaman radio, dan tombol apply.
/// Design: pic 2 — "Filter & Cari"
class ClientSearchScreen extends StatefulWidget {
  const ClientSearchScreen({super.key});

  @override
  State<ClientSearchScreen> createState() => _ClientSearchScreenState();
}

class _ClientSearchScreenState extends State<ClientSearchScreen> {
  // Controller untuk text field search
  final _searchCtrl = TextEditingController();

  // ── State untuk semua filter ────────────────────────────────

  // Kategori: set index yang aktif (bisa multi-select)
  final Set<int> _activeCategories = {0}; // Default: index 0 aktif

  // Range harga (slider)
  RangeValues _priceRange = const RangeValues(50000, 10000000);

  // Rating minimum: 0 = semua, 1 = 4.0+, 2 = 4.5+
  int _ratingIndex = 1; // Default: 4.0+

  // Tingkat pengalaman: 0 = Junior, 1 = Intermediate, 2 = Senior
  int _experienceIndex = 1; // Default: Intermediate

  // Data kategori
  final List<String> _categories = [
    'UI/UX Design',
    'Web Development',
    'Copywriting',
    'Graphics Design',
    'Marketing',
  ];

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  /// Reset semua filter ke default
  void _resetAll() {
    setState(() {
      _searchCtrl.clear();
      _activeCategories
        ..clear()
        ..add(0);
      _priceRange = const RangeValues(50000, 10000000);
      _ratingIndex = 1;
      _experienceIndex = 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isId = LanguageNotifier.instance.isIndonesian;

    return Scaffold(
      backgroundColor: FPal.bg,
      // ── App Bar ─────────────────────────────────────────────
      appBar: AppBar(
        backgroundColor: FPal.bg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: FPal.ink),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          isId ? 'Filter & Cari' : 'Filter & Search',
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: FPal.ink,
          ),
        ),
        centerTitle: true,
        actions: [
          // Tombol "Reset" di kanan atas
          TextButton(
            onPressed: _resetAll,
            child: Text(
              'Reset',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: FPal.inkSoft,
              ),
            ),
          ),
        ],
      ),

      // ── Body ────────────────────────────────────────────────
      body: AnimatedPage(
        child: Column(
          children: [
            // Scrollable content area
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
                children: [
                  // ── Search Field ────────────────────────────────
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0xFFDDE2EE)),
                    ),
                    child: TextField(
                      controller: _searchCtrl,
                      decoration: InputDecoration(
                        hintText: isId
                            ? 'Cari freelancer atau keahlian...'
                            : 'Search freelancer or skills...',
                        hintStyle: const TextStyle(
                          color: FPal.inkMuted,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                        prefixIcon: const Icon(Icons.search_rounded, color: FPal.inkMuted, size: 22),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                    ),
                  ),
                  const SizedBox(height: 26),

                  // ── Kategori ────────────────────────────────────
                  Text(
                    isId ? 'Kategori' : 'Category',
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      color: FPal.ink,
                    ),
                  ),
                  const SizedBox(height: 14),
                  // Wrap chips agar bisa multi-row
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: List.generate(_categories.length, (index) {
                      final isActive = _activeCategories.contains(index);
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            // Toggle: kalau sudah active, remove. Kalau belum, add.
                            if (isActive) {
                              _activeCategories.remove(index);
                            } else {
                              _activeCategories.add(index);
                            }
                          });
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
                          decoration: BoxDecoration(
                            color: isActive ? FPal.primary : Colors.white,
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(
                              color: isActive ? FPal.primary : const Color(0xFFDDE2EE),
                            ),
                          ),
                          child: Text(
                            _categories[index],
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: isActive ? Colors.white : FPal.inkSoft,
                            ),
                          ),
                        ),
                      );
                    }),
                  ),
                  const SizedBox(height: 28),

                  // ── Rentang Harga ───────────────────────────────
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        isId ? 'Rentang Harga' : 'Price Range',
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                          color: FPal.ink,
                        ),
                      ),
                      Text(
                        isId ? 'Per Jam' : 'Per Hour',
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: FPal.primary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  // Min & Max text fields
                  Row(
                    children: [
                      // Minimum
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Minimum',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: FPal.inkMuted,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: const Color(0xFFDDE2EE)),
                              ),
                              child: Text(
                                'Rp ${_formatNum(_priceRange.start.toInt())}',
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: FPal.ink,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 14),
                      // Maksimum
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              isId ? 'Maksimum' : 'Maximum',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: FPal.inkMuted,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: const Color(0xFFDDE2EE)),
                              ),
                              child: Text(
                                _priceRange.end >= 10000000
                                    ? 'Rp ${isId ? "Tak terbatas" : "Unlimited"}'
                                    : 'Rp ${_formatNum(_priceRange.end.toInt())}',
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: FPal.ink,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  // Range Slider — dua thumb handle hijau
                  SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      activeTrackColor: FPal.primary,
                      inactiveTrackColor: const Color(0xFFE0E0E0),
                      thumbColor: FPal.primary,
                      overlayColor: FPal.primary.withOpacity(0.15),
                      thumbShape: const RoundSliderThumbShape(
                        enabledThumbRadius: 10,
                        elevation: 2,
                      ),
                      trackHeight: 4,
                    ),
                    child: RangeSlider(
                      values: _priceRange,
                      min: 0,
                      max: 10000000,
                      divisions: 100,
                      onChanged: (values) {
                        setState(() => _priceRange = values);
                      },
                    ),
                  ),
                  const SizedBox(height: 24),

                  // ── Rating Minimum ──────────────────────────────
                  Text(
                    isId ? 'Rating Minimum' : 'Minimum Rating',
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      color: FPal.ink,
                    ),
                  ),
                  const SizedBox(height: 14),
                  // Rating pills: Semua, 4.0+, 4.5+
                  Row(
                    children: [
                      _RatingPill(
                        label: isId ? 'Semua' : 'All',
                        isActive: _ratingIndex == 0,
                        onTap: () => setState(() => _ratingIndex = 0),
                      ),
                      const SizedBox(width: 10),
                      _RatingPill(
                        label: '4.0+',
                        isActive: _ratingIndex == 1,
                        showStar: true,
                        onTap: () => setState(() => _ratingIndex = 1),
                      ),
                      const SizedBox(width: 10),
                      _RatingPill(
                        label: '4.5+',
                        isActive: _ratingIndex == 2,
                        showStar: true,
                        onTap: () => setState(() => _ratingIndex = 2),
                      ),
                    ],
                  ),
                  const SizedBox(height: 28),

                  // ── Lokasi ──────────────────────────────────────
                  Text(
                    isId ? 'Lokasi' : 'Location',
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      color: FPal.ink,
                    ),
                  ),
                  const SizedBox(height: 14),
                  // Dropdown lokasi
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0xFFDDE2EE)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.location_on_outlined, color: FPal.inkMuted, size: 20),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            isId ? 'Semua Lokasi' : 'All Locations',
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: FPal.ink,
                            ),
                          ),
                        ),
                        const Icon(Icons.keyboard_arrow_down_rounded, color: FPal.inkMuted, size: 22),
                      ],
                    ),
                  ),
                  const SizedBox(height: 28),

                  // ── Tingkat Pengalaman ───────────────────────────
                  Text(
                    isId ? 'Tingkat Pengalaman' : 'Experience Level',
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      color: FPal.ink,
                    ),
                  ),
                  const SizedBox(height: 14),
                  // Radio options: Junior, Intermediate, Senior
                  _ExperienceOption(
                    title: 'Junior',
                    subtitle: isId ? 'Pengalaman 0–2 tahun' : '0–2 years experience',
                    isSelected: _experienceIndex == 0,
                    onTap: () => setState(() => _experienceIndex = 0),
                  ),
                  const SizedBox(height: 10),
                  _ExperienceOption(
                    title: 'Intermediate',
                    subtitle: isId ? 'Pengalaman 2–5 tahun' : '2–5 years experience',
                    isSelected: _experienceIndex == 1,
                    onTap: () => setState(() => _experienceIndex = 1),
                  ),
                  const SizedBox(height: 10),
                  _ExperienceOption(
                    title: 'Senior',
                    subtitle: isId ? 'Pengalaman 5+ tahun' : '5+ years experience',
                    isSelected: _experienceIndex == 2,
                    onTap: () => setState(() => _experienceIndex = 2),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),

            // ── Tombol "Terapkan Filter" (sticky bottom) ──────
            Container(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
              decoration: BoxDecoration(
                color: FPal.bg,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, -2),
                  ),
                ],
              ),
              child: SafeArea(
                top: false,
                child: GestureDetector(
                  onTap: () {
                    // TODO: apply filter dan kembali dengan results
                    Navigator.pop(context);
                  },
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      color: FPal.primary,
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: FPal.primary.withOpacity(0.3),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          isId ? 'Terapkan Filter' : 'Apply Filter',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(width: 8),
                        const Icon(Icons.filter_alt_rounded, color: Colors.white, size: 20),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Format angka: 50000 → "50.000"
  String _formatNum(int n) {
    final str = n.toString();
    final buffer = StringBuffer();
    for (int i = 0; i < str.length; i++) {
      if (i > 0 && (str.length - i) % 3 == 0) buffer.write('.');
      buffer.write(str[i]);
    }
    return buffer.toString();
  }
}

/// Pill untuk rating minimum — bisa ada icon bintang
class _RatingPill extends StatelessWidget {
  final String label;
  final bool isActive;
  final bool showStar;
  final VoidCallback onTap;

  const _RatingPill({
    required this.label,
    required this.isActive,
    this.showStar = false,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
        decoration: BoxDecoration(
          color: isActive ? FPal.primary : Colors.white,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: isActive ? FPal.primary : const Color(0xFFDDE2EE),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (showStar) ...[
              Icon(
                isActive ? Icons.star_rounded : Icons.star_outline_rounded,
                size: 16,
                color: isActive ? const Color(0xFFFFA726) : const Color(0xFFFFA726),
              ),
              const SizedBox(width: 5),
            ],
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: isActive ? Colors.white : FPal.inkSoft,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Option radio untuk tingkat pengalaman
class _ExperienceOption extends StatelessWidget {
  final String title;
  final String subtitle;
  final bool isSelected;
  final VoidCallback onTap;

  const _ExperienceOption({
    required this.title,
    required this.subtitle,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          // Selected: bg hijau muda, border hijau
          color: isSelected ? FPal.primaryLight : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? FPal.primary : const Color(0xFFDDE2EE),
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            // Info text
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: isSelected ? FPal.primary : FPal.ink,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: isSelected ? FPal.primary.withOpacity(0.7) : FPal.inkMuted,
                    ),
                  ),
                ],
              ),
            ),
            // Radio circle
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: isSelected ? FPal.primary : const Color(0xFFCCC8C3),
                  width: isSelected ? 7 : 2,
                ),
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
