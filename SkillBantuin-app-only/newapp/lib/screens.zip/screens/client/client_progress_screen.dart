import 'package:flutter/material.dart';
import '../../utils/language_notifier.dart';
import '../../widgets/app_theme.dart';
import '../../widgets/app_animations.dart';

/// Progress Screen untuk Client — menampilkan overview tugas aktif,
/// daftar proyek dengan progress bar, dan aktivitas terbaru.
/// Design: pic 3 — "Progres Tugas"
class ClientProgressScreen extends StatefulWidget {
  const ClientProgressScreen({super.key});

  @override
  State<ClientProgressScreen> createState() => _ClientProgressScreenState();
}

class _ClientProgressScreenState extends State<ClientProgressScreen> {
  @override
  void initState() {
    super.initState();
    LanguageNotifier.instance.addListener(_onLang);
  }

  @override
  void dispose() {
    LanguageNotifier.instance.removeListener(_onLang);
    super.dispose();
  }

  void _onLang() => setState(() {});

  /// Data dummy proyek
  List<_ProjectData> get _projects => [
        const _ProjectData(
          title: 'Desain UI/UX Mobile App',
          freelancerName: 'Andi Pratama',
          progress: 0.75,
          status: 'On Track',
          statusColor: Color(0xFF1A6B55),
          statusBg: Color(0xFFD1FAE5),
        ),
        const _ProjectData(
          title: 'Pengembangan Backend API',
          freelancerName: 'Siti Aminah',
          progress: 0.40,
          status: 'Review Needed',
          statusColor: Color(0xFFB8860B),
          statusBg: Color(0xFFFEF3C7),
        ),
      ];

  /// Data dummy aktivitas
  List<_ActivityData> get _activities {
    final isId = LanguageNotifier.instance.isIndonesian;
    return [
      _ActivityData(
        icon: Icons.upload_file_rounded,
        iconColor: FPal.primary,
        iconBg: FPal.primaryLight,
        richText: [
          const _RichPart('Andi Pratama', true),
          _RichPart(isId ? ' mengunggah file revisi UI' : ' uploaded UI revision file', false),
        ],
        time: isId ? '2 jam yang lalu' : '2 hours ago',
      ),
      _ActivityData(
        icon: Icons.check_circle_rounded,
        iconColor: FPal.success,
        iconBg: FPal.successLight,
        richText: [
          _RichPart(isId ? 'Tugas ' : 'Task ', false),
          const _RichPart('Setup Database', true),
          _RichPart(isId ? ' selesai' : ' completed', false),
        ],
        time: isId ? 'Kemarin, 15:45' : 'Yesterday, 15:45',
      ),
      _ActivityData(
        icon: Icons.chat_bubble_outline_rounded,
        iconColor: FPal.inkSoft,
        iconBg: FPal.bgMuted,
        richText: [
          const _RichPart('Siti Aminah', true),
          _RichPart(isId ? ' meninggalkan komentar' : ' left a comment', false),
        ],
        time: isId ? 'Kemarin, 10:20' : 'Yesterday, 10:20',
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final isId = LanguageNotifier.instance.isIndonesian;

    return Scaffold(
      backgroundColor: FPal.bg,
      body: SafeArea(
        child: AnimatedPage(
          child: CustomScrollView(
            slivers: [
              // ── App Bar ─────────────────────────────────────────
              SliverAppBar(
                backgroundColor: FPal.bg,
                elevation: 0,
                floating: true,
                pinned: false,
                automaticallyImplyLeading: false,
                leadingWidth: 48,
                leading: Padding(
                  padding: const EdgeInsets.only(left: 16),
                  child: Icon(Icons.menu_rounded, color: FPal.ink, size: 24),
                ),
                title: const Text(
                  'SkillBantuin',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: FPal.ink,
                    letterSpacing: -0.3,
                  ),
                ),
                actions: [
                  // Notification bell + avatar di kanan
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: FPal.primary, width: 2),
                        ),
                        child: ClipOval(
                          child: Container(
                            color: FPal.primaryLight,
                            child: const Icon(Icons.notifications_outlined, color: FPal.primary, size: 18),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(width: 16),
                ],
              ),

              // ── Content ─────────────────────────────────────────
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([
                    const SizedBox(height: 8),

                    // ── Title & Subtitle ──────────────────────────
                    FadeScaleIn(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            isId ? 'Progres Tugas' : 'Task Progress',
                            style: const TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.w900,
                              color: FPal.ink,
                              letterSpacing: -0.5,
                              height: 1.1,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            isId
                                ? 'Pantau penyelesaian proyek Anda'
                                : 'Monitor your project completion',
                            style: const TextStyle(
                              fontSize: 14,
                              color: FPal.inkMuted,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 22),

                    // ── Stats Cards Row ───────────────────────────
                    // BounceIn — dramatic elastic entrance untuk stats
                    BounceIn(
                      delay: const Duration(milliseconds: 200),
                      duration: const Duration(milliseconds: 800),
                      child: Row(
                        children: [
                          // Card "Tugas Aktif" — gradient background
                          Expanded(
                            child: Container(
                              padding: const EdgeInsets.all(18),
                              decoration: BoxDecoration(
                                gradient: FPal.heroGradient,
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [
                                  BoxShadow(
                                    color: FPal.primary.withOpacity(0.3),
                                    blurRadius: 12,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // Icon clipboard
                                  Container(
                                    width: 34,
                                    height: 34,
                                    decoration: BoxDecoration(
                                      color: Colors.white.withOpacity(0.2),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: const Icon(Icons.assignment_rounded, color: Colors.white, size: 18),
                                  ),
                                  const SizedBox(height: 12),
                                  Text(
                                    isId ? 'Tugas Aktif' : 'Active Tasks',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white.withOpacity(0.8),
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  // Animated counter
                                  const AnimatedCounter(
                                    value: 12,
                                    style: TextStyle(
                                      fontSize: 32,
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(width: 14),
                          // Card "Tenggat Dekat" — putih
                          Expanded(
                            child: Container(
                              padding: const EdgeInsets.all(18),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: const Color(0xFFE8E5E0)),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.04),
                                    blurRadius: 12,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // Icon calendar
                                  Container(
                                    width: 34,
                                    height: 34,
                                    decoration: BoxDecoration(
                                      color: FPal.bgMuted,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: const Icon(Icons.calendar_today_rounded, color: FPal.ink, size: 18),
                                  ),
                                  const SizedBox(height: 12),
                                  Text(
                                    isId ? 'Tenggat Dekat' : 'Due Soon',
                                    style: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: FPal.inkMuted,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  const AnimatedCounter(
                                    value: 3,
                                    prefix: '0',
                                    style: TextStyle(
                                      fontSize: 32,
                                      fontWeight: FontWeight.w900,
                                      color: FPal.ink,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 28),

                    // ── Daftar Proyek Header ──────────────────────
                    Text(
                      isId ? 'Daftar Proyek' : 'Project List',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: FPal.ink,
                      ),
                    ),
                    const SizedBox(height: 14),

                    // ── Project Cards — slide dari kanan ──────────
                    ...List.generate(_projects.length, (index) {
                      return SlideInRight(
                        delay: Duration(milliseconds: 400 + index * 150),
                        duration: const Duration(milliseconds: 550),
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 14),
                          child: _ProjectCard(data: _projects[index], isId: isId),
                        ),
                      );
                    }),
                    const SizedBox(height: 24),

                    // ── Aktivitas Terbaru ─────────────────────────
                    Text(
                      isId ? 'Aktivitas Terbaru' : 'Recent Activity',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: FPal.ink,
                      ),
                    ),
                    const SizedBox(height: 16),

                    // ── Activity Items — slide dari kiri ──────────
                    ...List.generate(_activities.length, (index) {
                      return SlideInLeft(
                        delay: Duration(milliseconds: 700 + index * 120),
                        duration: const Duration(milliseconds: 500),
                        child: _ActivityItem(
                          data: _activities[index],
                          isLast: index == _activities.length - 1,
                        ),
                      );
                    }),

                    const SizedBox(height: 30),
                  ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  DATA MODELS & WIDGETS
// ══════════════════════════════════════════════════════════════════════════════

/// Data proyek
class _ProjectData {
  final String title;
  final String freelancerName;
  final double progress; // 0.0 – 1.0
  final String status;
  final Color statusColor;
  final Color statusBg;

  const _ProjectData({
    required this.title,
    required this.freelancerName,
    required this.progress,
    required this.status,
    required this.statusColor,
    required this.statusBg,
  });
}

/// Card proyek — menampilkan title, status badge, freelancer, progress bar
class _ProjectCard extends StatelessWidget {
  final _ProjectData data;
  final bool isId;

  const _ProjectCard({required this.data, required this.isId});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Row atas: Title + Status badge
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title proyek
              Expanded(
                child: Text(
                  data.title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: FPal.ink,
                    height: 1.2,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              // Status badge
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: data.statusBg,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  data.status,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: data.statusColor,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Freelancer avatar + name
          Row(
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: FPal.primaryLight,
                  border: Border.all(color: FPal.primary.withOpacity(0.3)),
                ),
                child: const Icon(Icons.person, color: FPal.primary, size: 15),
              ),
              const SizedBox(width: 8),
              Text(
                data.freelancerName,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: FPal.inkSoft,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // Progress label + percentage
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                isId ? 'Penyelesaian' : 'Completion',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: FPal.primary,
                ),
              ),
              Text(
                '${(data.progress * 100).toInt()}%',
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: FPal.ink,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Progress bar — animated
          _AnimatedProgressBar(value: data.progress),
        ],
      ),
    );
  }
}

/// Progress bar dengan animasi dari 0 ke target value
class _AnimatedProgressBar extends StatefulWidget {
  final double value;
  const _AnimatedProgressBar({required this.value});

  @override
  State<_AnimatedProgressBar> createState() => _AnimatedProgressBarState();
}

class _AnimatedProgressBarState extends State<_AnimatedProgressBar>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    // Controller untuk animasi progress bar
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    // Tween dari 0 ke target value
    _anim = Tween<double>(begin: 0, end: widget.value).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic),
    );
    // Delay sedikit sebelum mulai animasi
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) {
        return Container(
          height: 8,
          decoration: BoxDecoration(
            color: const Color(0xFFE8E5E0),
            borderRadius: BorderRadius.circular(4),
          ),
          child: FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: _anim.value.clamp(0, 1),
            child: Container(
              decoration: BoxDecoration(
                color: FPal.primary,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Data aktivitas
class _RichPart {
  final String text;
  final bool isBold;
  const _RichPart(this.text, this.isBold);
}

class _ActivityData {
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final List<_RichPart> richText;
  final String time;

  const _ActivityData({
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.richText,
    required this.time,
  });
}

/// Item aktivitas — timeline style dengan garis vertikal
class _ActivityItem extends StatelessWidget {
  final _ActivityData data;
  final bool isLast;

  const _ActivityItem({required this.data, this.isLast = false});

  @override
  Widget build(BuildContext context) {
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Timeline: icon + garis vertikal
          Column(
            children: [
              // Icon circle
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: data.iconBg,
                ),
                child: Icon(data.icon, color: data.iconColor, size: 18),
              ),
              // Garis vertikal — hidden kalau item terakhir
              if (!isLast)
                Expanded(
                  child: Container(
                    width: 2,
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    color: const Color(0xFFE8E5E0),
                  ),
                ),
            ],
          ),
          const SizedBox(width: 14),
          // Content: rich text + timestamp
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 2),
                  // Rich text — beberapa bagian bold, beberapa normal
                  Text.rich(
                    TextSpan(
                      children: data.richText.map((part) {
                        return TextSpan(
                          text: part.text,
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: part.isBold ? FontWeight.w800 : FontWeight.w500,
                            color: FPal.ink,
                            height: 1.4,
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(height: 4),
                  // Timestamp
                  Text(
                    data.time,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: FPal.inkMuted,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
