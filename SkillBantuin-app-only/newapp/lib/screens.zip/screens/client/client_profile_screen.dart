import 'package:flutter/material.dart';
import '../../utils/language_notifier.dart';
import '../../widgets/app_theme.dart';
import '../../widgets/app_animations.dart';

/// Profile Screen untuk Client — menampilkan info profil, stats, settings.
/// Design: pic 6 — avatar, Edit Profile, stats cards, Account/General/Support sections, logout
class ClientProfileScreen extends StatefulWidget {
  const ClientProfileScreen({super.key});

  @override
  State<ClientProfileScreen> createState() => _ClientProfileScreenState();
}

class _ClientProfileScreenState extends State<ClientProfileScreen> {
  // State dark mode toggle
  bool _darkMode = false;

  @override
  void initState() {
    super.initState();
    LanguageNotifier.instance.addListener(_onLang);
  }

  @override
  void dispose() {
    LanguageNotifier.instance.removeListener(_onLang);
    super.dispose();
  }

  void _onLang() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final isId = LanguageNotifier.instance.isIndonesian;

    return Scaffold(
      backgroundColor: FPal.bg,
      body: SafeArea(
        child: AnimatedPage(
          child: Column(
            children: [
              // ── App Bar ─────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: Row(
                  children: [
                    // Hamburger menu icon
                    const Icon(Icons.menu_rounded, color: FPal.ink, size: 24),
                    const SizedBox(width: 14),
                    // Logo "SkillBantuin"
                    const Text(
                      'SkillBantuin',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: FPal.ink,
                        letterSpacing: -0.3,
                      ),
                    ),
                    const Spacer(),
                    // Profile avatar kanan atas
                    Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: FPal.primary, width: 2),
                      ),
                      child: ClipOval(
                        child: Container(
                          color: FPal.primaryLight,
                          child: const Icon(Icons.person, color: FPal.primary, size: 20),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // ── Garis hijau di bawah app bar ────────────────────
              const SizedBox(height: 12),
              Container(height: 2, color: FPal.primaryLight),

              // ── Scrollable Content ──────────────────────────────
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
                  children: [
                    // ── Profile Card — bounce entrance ──────────
                    BounceIn(
                      delay: const Duration(milliseconds: 100),
                      duration: const Duration(milliseconds: 800),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 28),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.04),
                              blurRadius: 16,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            // Avatar besar dengan ring + verified badge
                            Stack(
                              alignment: Alignment.center,
                              children: [
                                // Ring luar abu-abu
                                Container(
                                  width: 96,
                                  height: 96,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: const Color(0xFFDDE2EE),
                                      width: 3,
                                    ),
                                  ),
                                ),
                                // Avatar
                                Container(
                                  width: 84,
                                  height: 84,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: FPal.primaryLight,
                                  ),
                                  child: const Icon(Icons.person, color: FPal.primary, size: 42),
                                ),
                                // Verified badge — posisi kanan bawah
                                Positioned(
                                  bottom: 0,
                                  right: 0,
                                  child: Container(
                                    width: 30,
                                    height: 30,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: FPal.primary,
                                      border: Border.all(color: Colors.white, width: 2.5),
                                    ),
                                    child: const Icon(Icons.verified_rounded, color: Colors.white, size: 16),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            // Nama
                            const Text(
                              'Andi Pratama',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                color: FPal.ink,
                              ),
                            ),
                            const SizedBox(height: 4),
                            // Role label
                            const Text(
                              'Premium Client',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                                color: FPal.inkMuted,
                              ),
                            ),
                            const SizedBox(height: 18),
                            // Tombol "Edit Profile"
                            GestureDetector(
                              onTap: () {
                                // TODO: navigasi ke edit profile
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                                decoration: BoxDecoration(
                                  color: FPal.primary,
                                  borderRadius: BorderRadius.circular(12),
                                  boxShadow: [
                                    BoxShadow(
                                      color: FPal.primary.withOpacity(0.3),
                                      blurRadius: 8,
                                      offset: const Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Icon(Icons.edit_rounded, color: Colors.white, size: 16),
                                    const SizedBox(width: 8),
                                    Text(
                                      isId ? 'Edit Profil' : 'Edit Profile',
                                      style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w700,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),

                    // ── Stats Row ─────────────────────────────────
                    // 3 card: Total Projects, Ongoing, Reviews Given
                    FadeScaleIn(
                      delay: const Duration(milliseconds: 150),
                      child: Row(
                        children: [
                          _StatCard(
                            value: '12',
                            label: isId ? 'Total\nProyek' : 'Total\nProjects',
                          ),
                          const SizedBox(width: 10),
                          _StatCard(
                            value: '3',
                            label: isId ? 'Sedang\nBerjalan' : 'Ongoing',
                          ),
                          const SizedBox(width: 10),
                          _StatCard(
                            value: '8',
                            label: isId ? 'Review\nDiberikan' : 'Reviews\nGiven',
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // ── Account Section ───────────────────────────
                    _SectionLabel(text: 'Account'),
                    const SizedBox(height: 10),
                    _SettingsGroup(
                      children: [
                        _SettingsTile(
                          icon: Icons.person_outline_rounded,
                          title: isId ? 'Informasi Pribadi' : 'Personal Information',
                          onTap: () {},
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // ── General Section ───────────────────────────
                    _SectionLabel(text: 'General'),
                    const SizedBox(height: 10),
                    _SettingsGroup(
                      children: [
                        _SettingsTile(
                          icon: Icons.notifications_outlined,
                          title: isId ? 'Notifikasi' : 'Notifications',
                          onTap: () {},
                        ),
                        Container(height: 1, color: const Color(0xFFF0EDE8)),
                        _SettingsTile(
                          icon: Icons.dark_mode_outlined,
                          title: 'Dark Mode',
                          trailing: Switch(
                            value: _darkMode,
                            onChanged: (v) => setState(() => _darkMode = v),
                            activeColor: FPal.primary,
                            inactiveTrackColor: const Color(0xFFDDE2EE),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // ── Support Section ───────────────────────────
                    _SectionLabel(text: 'Support'),
                    const SizedBox(height: 10),
                    _SettingsGroup(
                      children: [
                        _SettingsTile(
                          icon: Icons.help_outline_rounded,
                          title: isId ? 'Pusat Bantuan' : 'Help Center',
                          onTap: () {},
                        ),
                        Container(height: 1, color: const Color(0xFFF0EDE8)),
                        _SettingsTile(
                          icon: Icons.language_rounded,
                          title: isId ? 'Language / Bahasa' : 'Language / Bahasa',
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              // Flag Indonesia
                              GestureDetector(
                                onTap: () => LanguageNotifier.instance.setLanguage('id'),
                                child: Container(
                                  width: 32,
                                  height: 32,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: isId ? FPal.primaryLight : FPal.bgMuted,
                                    border: Border.all(
                                      color: isId ? FPal.primary : const Color(0xFFDDE2EE),
                                      width: isId ? 2 : 1,
                                    ),
                                  ),
                                  child: Center(
                                    child: Text(
                                      '🇮🇩',
                                      style: TextStyle(fontSize: 16),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              // Flag US/English
                              GestureDetector(
                                onTap: () => LanguageNotifier.instance.setLanguage('en'),
                                child: Container(
                                  width: 32,
                                  height: 32,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: !isId ? FPal.primaryLight : FPal.bgMuted,
                                    border: Border.all(
                                      color: !isId ? FPal.primary : const Color(0xFFDDE2EE),
                                      width: !isId ? 2 : 1,
                                    ),
                                  ),
                                  child: Center(
                                    child: Text(
                                      '🇺🇸',
                                      style: TextStyle(fontSize: 16),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 28),

                    // ── Log Out Button ────────────────────────────
                    GestureDetector(
                      onTap: () {
                        // TODO: logout logic
                      },
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFDE8E8),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.logout_rounded, color: FPal.danger, size: 20),
                            const SizedBox(width: 8),
                            Text(
                              'Log Out',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w700,
                                color: FPal.danger,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),

                    // ── Version Footer ────────────────────────────
                    Center(
                      child: Text(
                        'SkillBantuin v1.0.24 • Made with Trust',
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: FPal.inkMuted,
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  REUSABLE WIDGETS
// ══════════════════════════════════════════════════════════════════════════════

/// Card statistik (Total Projects, Ongoing, Reviews Given)
class _StatCard extends StatelessWidget {
  final String value;
  final String label;

  const _StatCard({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFE8E5E0)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.03),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            Text(
              value,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w900,
                color: FPal.primary,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: FPal.inkMuted,
                height: 1.3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Section label (e.g. "Account", "General", "Support")
class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel({required this.text});

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w700,
        color: FPal.primary,
      ),
    );
  }
}

/// Container untuk group settings tiles
class _SettingsGroup extends StatelessWidget {
  final List<Widget> children;
  const _SettingsGroup({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(children: children),
    );
  }
}

/// Satu tile di settings — icon, title, trailing (chevron/switch/custom)
class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback? onTap;
  final Widget? trailing;

  const _SettingsTile({
    required this.icon,
    required this.title,
    this.onTap,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Icon(icon, color: FPal.inkSoft, size: 22),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: FPal.ink,
                ),
              ),
            ),
            // Trailing: custom widget atau default chevron
            trailing ?? const Icon(Icons.chevron_right_rounded, color: FPal.inkMuted, size: 22),
          ],
        ),
      ),
    );
  }
}
