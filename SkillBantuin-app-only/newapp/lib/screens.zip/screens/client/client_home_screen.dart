import 'package:flutter/material.dart';
import '../../utils/language_notifier.dart';
import '../../widgets/app_theme.dart';
import '../../widgets/app_animations.dart';
import 'client_search_screen.dart';

class ClientHomeScreen extends StatefulWidget {
  const ClientHomeScreen({super.key});
  @override
  State<ClientHomeScreen> createState() => _ClientHomeScreenState();
}

class _ClientHomeScreenState extends State<ClientHomeScreen> {
  int _activeCategoryIndex = 0;

  @override
  void initState() {
    super.initState();
    LanguageNotifier.instance.addListener(_onLang);
  }

  @override
  void dispose() {
    LanguageNotifier.instance.removeListener(_onLang);
    super.dispose();
  }

  void _onLang() => setState(() {});

  List<String> get _categories => ['UI Design', 'Copywriting', 'Web Dev'];

  List<_FreelancerData> get _freelancers => const [
        _FreelancerData(name: 'Budi Santoso', skill: 'Logo Designer', rating: 4.9,
            price: 'Rp 500k', buttonType: _BtnType.hire, avatarColor: Color(0xFF2E7D5E)),
        _FreelancerData(name: 'Siti Aminah', skill: 'UI/UX Designer', rating: 5.0,
            price: 'Rp 1.2M', buttonType: _BtnType.viewProfile, avatarColor: Color(0xFF1B5E40)),
        _FreelancerData(name: 'Andi Wijaya', skill: 'Web Developer', rating: 4.8,
            price: 'Rp 2.5M', buttonType: _BtnType.hire, avatarColor: Color(0xFF34495E)),
      ];

  void _goSearch() => Navigator.push(context, MaterialPageRoute(builder: (_) => const ClientSearchScreen()));

  @override
  Widget build(BuildContext context) {
    final isId = LanguageNotifier.instance.isIndonesian;

    return Scaffold(
      backgroundColor: FPal.bg,
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            // ═══ APP BAR — logo slide kiri, avatar bounce ═══
            SlideInLeft(
              duration: const Duration(milliseconds: 600),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('SkillBantuin', style: TextStyle(fontSize: 20,
                        fontWeight: FontWeight.w900, color: FPal.ink, letterSpacing: -0.3)),
                    BounceIn(
                      delay: const Duration(milliseconds: 300),
                      child: Container(
                        width: 40, height: 40,
                        decoration: BoxDecoration(shape: BoxShape.circle,
                            border: Border.all(color: FPal.primary, width: 2)),
                        child: ClipOval(child: Container(color: FPal.primaryLight,
                            child: const Icon(Icons.person, color: FPal.primary, size: 22))),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // ═══ HERO TEXT — elastic bounce ═══
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: BounceIn(
                delay: const Duration(milliseconds: 150),
                duration: const Duration(milliseconds: 900),
                child: Text.rich(TextSpan(children: [
                  TextSpan(text: isId ? 'Temukan\n' : 'Find the best\n',
                      style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w900,
                          color: FPal.ink, height: 1.15, letterSpacing: -0.5)),
                  TextSpan(text: isId ? 'talenta freelance.' : 'freelance talent.',
                      style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w900,
                          color: FPal.primary, height: 1.15, letterSpacing: -0.5)),
                ])),
              ),
            ),
            const SizedBox(height: 22),

            // ═══ SEARCH BAR — slide up tebal ═══
            SlideUp(
              delay: const Duration(milliseconds: 300),
              distance: 0.2,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: GestureDetector(
                  onTap: _goSearch,
                  child: Container(
                    height: 52,
                    padding: const EdgeInsets.only(left: 16, right: 6),
                    decoration: BoxDecoration(
                      color: Colors.white, borderRadius: BorderRadius.circular(28),
                      border: Border.all(color: const Color(0xFFDDE2EE)),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04),
                          blurRadius: 8, offset: const Offset(0, 2))],
                    ),
                    child: Row(children: [
                      const Icon(Icons.search_rounded, color: FPal.inkMuted, size: 22),
                      const SizedBox(width: 10),
                      Expanded(child: Text(
                          isId ? 'Cari skill atau freelancer...' : 'Search skills or freelancers...',
                          style: const TextStyle(color: FPal.inkMuted, fontSize: 14, fontWeight: FontWeight.w500))),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        decoration: BoxDecoration(color: FPal.primary, borderRadius: BorderRadius.circular(22)),
                        child: Text(isId ? 'Cari' : 'Search',
                            style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                      ),
                    ]),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),

            // ═══ CATEGORIES HEADER — slide up ═══
            SlideUp(
              delay: const Duration(milliseconds: 400),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(isId ? 'Kategori' : 'Categories',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: FPal.ink)),
                    GestureDetector(onTap: _goSearch,
                        child: Text(isId ? 'Lihat semua' : 'See all',
                            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: FPal.primary))),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            // Category pills — staggered slide dari kiri
            SizedBox(
              height: 40,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: _categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (context, index) {
                  final isActive = index == _activeCategoryIndex;
                  return SlideInLeft(
                    delay: Duration(milliseconds: 450 + index * 80),
                    duration: const Duration(milliseconds: 400),
                    child: GestureDetector(
                      onTap: () => setState(() => _activeCategoryIndex = index),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 250), curve: Curves.easeOut,
                        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                        decoration: BoxDecoration(
                          color: isActive ? FPal.primary : Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: isActive ? FPal.primary : const Color(0xFFDDE2EE)),
                        ),
                        child: Text(_categories[index], style: TextStyle(fontSize: 13,
                            fontWeight: FontWeight.w700, color: isActive ? Colors.white : FPal.inkSoft)),
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 24),

            // ═══ DIVIDER ═══
            SlideUp(delay: const Duration(milliseconds: 500),
                child: Container(margin: const EdgeInsets.symmetric(horizontal: 20),
                    height: 1, color: const Color(0xFFEEECE8))),
            const SizedBox(height: 20),

            // ═══ FREELANCER REKOMENDASI HEADER ═══
            SlideUp(
              delay: const Duration(milliseconds: 550),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(isId ? 'Freelancer Rekomendasi' : 'Recommended Freelancers',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: FPal.ink)),
                    GestureDetector(onTap: _goSearch,
                        child: const Icon(Icons.tune_rounded, color: FPal.ink, size: 22)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),

            // ═══ FREELANCER CARDS — slide dari kanan staggered ═══
            ...List.generate(_freelancers.length, (i) => SlideInRight(
                  delay: Duration(milliseconds: 600 + i * 120),
                  duration: const Duration(milliseconds: 550),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 14),
                    child: _FreelancerCard(data: _freelancers[i], isId: isId, onTap: () {}),
                  ),
                )),
            const SizedBox(height: 10),

            // ═══ WEEKLY SPOTLIGHT — fade+scale masuk lalu float ═══
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: FadeScaleIn(
                delay: const Duration(milliseconds: 900),
                duration: const Duration(milliseconds: 600),
                child: FloatingWidget(
                  amplitude: 4,
                  duration: const Duration(milliseconds: 3000),
                  child: _SpotlightBanner(isId: isId),
                ),
              ),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
enum _BtnType { hire, viewProfile }

class _FreelancerData {
  final String name, skill, price;
  final double rating;
  final _BtnType buttonType;
  final Color avatarColor;
  const _FreelancerData({required this.name, required this.skill, required this.rating,
      required this.price, required this.buttonType, required this.avatarColor});
}

class _FreelancerCard extends StatelessWidget {
  final _FreelancerData data;
  final bool isId;
  final VoidCallback onTap;
  const _FreelancerCard({required this.data, required this.isId, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return TapScale(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(16),
          border: Border(left: BorderSide(color: FPal.primary.withOpacity(0.3), width: 3)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 12, offset: const Offset(0, 4))],
        ),
        child: Column(children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(width: 52, height: 52,
                decoration: BoxDecoration(shape: BoxShape.circle, color: data.avatarColor.withOpacity(0.15),
                    border: Border.all(color: data.avatarColor.withOpacity(0.3), width: 1.5)),
                child: Icon(Icons.person, color: data.avatarColor, size: 26)),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SizedBox(height: 2),
              Text(data.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: FPal.ink)),
              const SizedBox(height: 2),
              Text(data.skill, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: FPal.inkMuted)),
            ])),
            Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.star_rounded, color: Color(0xFFFFA726), size: 18),
              const SizedBox(width: 3),
              Text(data.rating.toString(), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: FPal.ink)),
            ]),
          ]),
          const SizedBox(height: 14),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text.rich(TextSpan(children: [
              TextSpan(text: isId ? 'Mulai dari ' : 'Starts from ',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: FPal.inkMuted)),
              TextSpan(text: data.price,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: FPal.ink)),
            ])),
            _buildBtn(),
          ]),
        ]),
      ),
    );
  }

  Widget _buildBtn() {
    if (data.buttonType == _BtnType.hire) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
        decoration: BoxDecoration(color: FPal.primary, borderRadius: BorderRadius.circular(10)),
        child: const Text('Hire', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
      );
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10),
          border: Border.all(color: FPal.primary, width: 1.5)),
      child: Text(isId ? 'Lihat\nProfil' : 'View\nProfile', textAlign: TextAlign.center,
          style: const TextStyle(color: FPal.primary, fontSize: 12, fontWeight: FontWeight.w700, height: 1.2)),
    );
  }
}

class _SpotlightBanner extends StatelessWidget {
  final bool isId;
  const _SpotlightBanner({required this.isId});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity, padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF0F3D2E), Color(0xFF1A6B55)]),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: FPal.primary.withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 8))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('WEEKLY SPOTLIGHT', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700,
            color: Colors.white.withOpacity(0.7), letterSpacing: 1.5)),
        const SizedBox(height: 10),
        Text(isId ? 'Mulai proyek\nimpianmu hari ini' : 'Launch your dream\nproject today',
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Colors.white,
                height: 1.2, letterSpacing: -0.3)),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
          child: Text(isId ? 'Mulai Briefing' : 'Start Briefing',
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: FPal.primary)),
        ),
      ]),
    );
  }
}
