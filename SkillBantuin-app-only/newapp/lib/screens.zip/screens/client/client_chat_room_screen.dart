import 'package:flutter/material.dart';
import '../../widgets/app_theme.dart';
import '../../widgets/app_animations.dart';

/// Chat Room Screen untuk Client (nama: "RoomChat")
/// Menampilkan percakapan individual dengan satu freelancer.
/// Design: pic 5 — chat bubbles, image attachment, input bar
class ClientChatRoomScreen extends StatefulWidget {
  final String name;        // Nama freelancer
  final bool isOnline;      // Status online
  final Color avatarColor;  // Warna avatar placeholder

  const ClientChatRoomScreen({
    super.key,
    required this.name,
    required this.isOnline,
    required this.avatarColor,
  });

  @override
  State<ClientChatRoomScreen> createState() => _ClientChatRoomScreenState();
}

class _ClientChatRoomScreenState extends State<ClientChatRoomScreen> {
  final _messageCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();

  /// Data dummy pesan sesuai desain pic 5
  List<_MessageData> get _messages => [
        // Pesan dari freelancer (kiri, abu-abu)
        const _MessageData(
          content: 'Halo, saya sudah menyelesaikan revisi desain untuk proyek Anda. Silakan dicek kembali ya Pak.',
          isMe: false,
          time: '14:02',
          status: _MsgStatus.read,
        ),
        // Pesan dari client (kanan, hijau)
        const _MessageData(
          content: 'Terima kasih Siti, saya cek dulu ya. Apakah bagian footer sudah disesuaikan?',
          isMe: true,
          time: '14:05',
          status: _MsgStatus.read,
        ),
        // Pesan dari freelancer
        const _MessageData(
          content: 'Sudah Pak, saya sesuaikan dengan mockup terakhir.',
          isMe: false,
          time: '14:07',
          status: _MsgStatus.read,
        ),
        // Image attachment dari freelancer
        const _MessageData(
          content: '',
          isMe: false,
          time: '14:07',
          status: _MsgStatus.read,
          isImage: true,
          fileName: 'Rev_Final_Footer.png',
        ),
      ];

  @override
  void dispose() {
    _messageCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FPal.bg,
      // ── App Bar ─────────────────────────────────────────────
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        // Tombol back
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: FPal.ink),
          onPressed: () => Navigator.pop(context),
        ),
        titleSpacing: 0,
        title: Row(
          children: [
            // Avatar + online dot
            Stack(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: widget.avatarColor.withOpacity(0.12),
                    border: Border.all(color: widget.avatarColor.withOpacity(0.25)),
                  ),
                  child: Icon(Icons.person, color: widget.avatarColor, size: 20),
                ),
                if (widget.isOnline)
                  Positioned(
                    bottom: 1,
                    left: 1,
                    child: Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: FPal.success,
                        border: Border.all(color: Colors.white, width: 2),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 10),
            // Name + online status
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.name,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: FPal.ink,
                  ),
                ),
                if (widget.isOnline)
                  const Text(
                    'Online',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: FPal.success,
                    ),
                  ),
              ],
            ),
          ],
        ),
        actions: [
          // Call button
          IconButton(
            icon: const Icon(Icons.phone_rounded, color: FPal.ink, size: 22),
            onPressed: () {},
          ),
          // Video call button
          IconButton(
            icon: const Icon(Icons.videocam_rounded, color: FPal.ink, size: 22),
            onPressed: () {},
          ),
          const SizedBox(width: 4),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: const Color(0xFFEEECE8)),
        ),
      ),

      // ── Body ────────────────────────────────────────────────
      body: Column(
        children: [
          // Chat messages area
          Expanded(
            child: AnimatedPage(
              child: ListView(
                controller: _scrollCtrl,
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 10),
                children: [
                  // ── Date divider "Hari Ini" ─────────────────
                  Center(
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 20),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEEECE8),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        'Hari Ini',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: FPal.inkMuted,
                        ),
                      ),
                    ),
                  ),

                  // ── Messages ────────────────────────────────
                  ...List.generate(_messages.length, (index) {
                    final msg = _messages[index];
                    return AnimatedItem(
                      index: index,
                      delayMs: 80,
                      child: _MessageBubble(msg: msg),
                    );
                  }),
                ],
              ),
            ),
          ),

          // ── Input Bar ───────────────────────────────────────
          _InputBar(
            controller: _messageCtrl,
            onSend: () {
              if (_messageCtrl.text.trim().isEmpty) return;
              // TODO: send message via provider
              _messageCtrl.clear();
            },
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  DATA MODELS & WIDGETS
// ══════════════════════════════════════════════════════════════════════════════

/// Status pesan
enum _MsgStatus { sent, read }

/// Data model pesan
class _MessageData {
  final String content;
  final bool isMe;         // true = sent by client (kanan), false = received (kiri)
  final String time;
  final _MsgStatus status;
  final bool isImage;      // true = pesan berisi gambar
  final String? fileName;

  const _MessageData({
    required this.content,
    required this.isMe,
    required this.time,
    required this.status,
    this.isImage = false,
    this.fileName,
  });
}

/// Widget bubble pesan
class _MessageBubble extends StatelessWidget {
  final _MessageData msg;

  const _MessageBubble({required this.msg});

  @override
  Widget build(BuildContext context) {
    // Alignment: sent = kanan, received = kiri
    final alignment = msg.isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start;
    final bubbleColor = msg.isMe ? FPal.primary : const Color(0xFFF0EDE8);
    final textColor = msg.isMe ? Colors.white : FPal.ink;

    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Column(
        crossAxisAlignment: alignment,
        children: [
          // Bubble container
          Container(
            constraints: BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width * 0.72,
            ),
            padding: msg.isImage
                ? const EdgeInsets.all(6)
                : const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: bubbleColor,
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(16),
                topRight: const Radius.circular(16),
                // Tail: sudut yang datar berdasarkan siapa pengirim
                bottomLeft: Radius.circular(msg.isMe ? 16 : 4),
                bottomRight: Radius.circular(msg.isMe ? 4 : 16),
              ),
            ),
            child: msg.isImage ? _buildImageContent(context) : _buildTextContent(textColor),
          ),

          // Timestamp + read receipt
          Padding(
            padding: const EdgeInsets.only(top: 4, bottom: 10),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  msg.time,
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: FPal.inkMuted,
                  ),
                ),
                // Read receipt (double check) — hanya untuk pesan sent
                if (msg.isMe && msg.status == _MsgStatus.read) ...[
                  const SizedBox(width: 4),
                  Icon(
                    Icons.done_all_rounded,
                    size: 14,
                    color: FPal.primary,
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Build konten teks biasa
  Widget _buildTextContent(Color textColor) {
    return Text(
      msg.content,
      style: TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w500,
        color: textColor,
        height: 1.45,
      ),
    );
  }

  /// Build konten gambar + filename + download
  Widget _buildImageContent(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Image preview — placeholder
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Container(
            width: 200,
            height: 140,
            color: const Color(0xFF1A3025),
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Placeholder gambar — gradient gelap
                Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Color(0xFF162D22), Color(0xFF0A1F15)],
                    ),
                  ),
                ),
                // Icon placeholder
                Icon(Icons.image_rounded, color: Colors.white.withOpacity(0.3), size: 40),
              ],
            ),
          ),
        ),
        // File name + download icon
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Flexible(
                child: Text(
                  msg.fileName ?? 'File',
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: FPal.ink,
                  ),
                ),
              ),
              const SizedBox(width: 6),
              Icon(Icons.download_rounded, color: FPal.primary, size: 18),
            ],
          ),
        ),
      ],
    );
  }
}

/// Input bar di bawah chat — tombol "+", text field, emoji, send
class _InputBar extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onSend;

  const _InputBar({required this.controller, required this.onSend});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            // Tombol "+" untuk attachment
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFFDDE2EE)),
              ),
              child: const Icon(Icons.add_rounded, color: FPal.ink, size: 22),
            ),
            const SizedBox(width: 10),

            // Text field
            Expanded(
              child: Container(
                height: 44,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: FPal.bgMuted,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: controller,
                        decoration: const InputDecoration(
                          hintText: 'Ketik pesan...',
                          hintStyle: TextStyle(
                            color: FPal.inkMuted,
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                          ),
                          border: InputBorder.none,
                          isDense: true,
                          contentPadding: EdgeInsets.zero,
                        ),
                        style: const TextStyle(fontSize: 14, color: FPal.ink),
                      ),
                    ),
                    // Emoji icon
                    const Icon(Icons.emoji_emotions_outlined, color: FPal.inkMuted, size: 20),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 10),

            // Send button — lingkaran hijau dengan arrow
            GestureDetector(
              onTap: onSend,
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: FPal.primary,
                  boxShadow: [
                    BoxShadow(
                      color: FPal.primary.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
