import 'package:flutter/material.dart';
import '../services/session_service.dart';
import '../widgets/app_theme.dart';
import '../widgets/auth_flow_widgets.dart';
import 'role_selection_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen>
    with SingleTickerProviderStateMixin {
  final PageController _pc = PageController();
  late AnimationController _animCtrl;
  int _page = 0;

  final _pages = const [
    _OBData(
      icon: Icons.volunteer_activism_rounded,
      tag: 'KOLABORASI',
      title: 'Bantu sesama,\ntumbuh bersama',
      desc: 'Bagikan keahlianmu untuk membantu orang lain dalam tugas-tugas kecil yang bermakna.',
      accentColor: Color(0xFF93AAFF),
    ),
    _OBData(
      icon: Icons.emoji_events_rounded,
      tag: 'PENGHARGAAN',
      title: 'Setiap bantuan\nada nilainya',
      desc: 'Dapatkan poin, sertifikat, dan testimoni dari orang yang kamu bantu.',
      accentColor: Color(0xFFFFD580),
    ),
    _OBData(
      icon: Icons.bolt_rounded,
      tag: 'FLEKSIBEL',
      title: 'Cepat, mudah,\ndi mana saja',
      desc: 'Tugas kecil yang bisa diselesaikan dalam hitungan menit, kapan pun kamu siap.',
      accentColor: Color(0xFF6EE7B7),
    ),
  ];

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _animCtrl.forward();
  }

  @override
  void dispose() {
    _pc.dispose();
    _animCtrl.dispose();
    super.dispose();
  }

  Future<void> _finish() async {
    await SessionService().markOnboardingSeen();
    if (!mounted) return;
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const RoleSelectionScreen()));
  }

  void _nextPage() {
    if (_page == _pages.length - 1) {
      _finish();
    } else {
      _pc.nextPage(duration: const Duration(milliseconds: 320), curve: Curves.easeInOut);
    }
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    return Scaffold(
      body: AuthGradientBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              children: [
                const SizedBox(height: 16),
                _buildTopBar(),
                SizedBox(height: h * 0.05),
                Expanded(
                  child: PageView.builder(
                    controller: _pc,
                    itemCount: _pages.length,
                    onPageChanged: (i) {
                      setState(() => _page = i);
                      _animCtrl.forward(from: 0);
                    },
                    itemBuilder: (_, i) => _PageContent(
                      data: _pages[i],
                      isActive: i == _page,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                _buildBottom(),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
          ),
          child: Row(
            children: const [
              Icon(Icons.handshake_rounded, color: Colors.white, size: 18),
              SizedBox(width: 8),
              Text('SkillBantuin',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                  fontSize: 15,
                  letterSpacing: -0.2,
                ),
              ),
            ],
          ),
        ),
        const Spacer(),
        if (_page < _pages.length - 1)
          TextButton(
            onPressed: _finish,
            style: TextButton.styleFrom(
              foregroundColor: Colors.white.withValues(alpha: 0.6),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            ),
            child: const Text('Lewati', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          ),
      ],
    );
  }

  Widget _buildBottom() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withValues(alpha: 0.14)),
      ),
      child: Column(
        children: [
          // Progress dots
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(_pages.length, (i) => AnimatedContainer(
              duration: const Duration(milliseconds: 280),
              curve: Curves.easeOut,
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: _page == i ? 28 : 7,
              height: 7,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(99),
                color: _page == i
                    ? _pages[_page].accentColor
                    : Colors.white.withValues(alpha: 0.25),
              ),
            )),
          ),
          const SizedBox(height: 18),
          // CTA Button
          SizedBox(
            height: 52,
            child: ElevatedButton(
              onPressed: _nextPage,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: FPal.primary,
                minimumSize: const Size.fromHeight(52),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(_page == _pages.length - 1 ? 'Mulai Sekarang' : 'Lanjut'),
                  const SizedBox(width: 8),
                  const Icon(Icons.arrow_forward_rounded, size: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PageContent extends StatelessWidget {
  final _OBData data;
  final bool isActive;
  const _PageContent({required this.data, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Icon badge
        AnimatedContainer(
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeOutBack,
          width: 80, height: 80,
          decoration: BoxDecoration(
            color: data.accentColor.withValues(alpha: isActive ? 0.18 : 0.08),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: data.accentColor.withValues(alpha: 0.4)),
          ),
          child: Icon(data.icon, size: 36, color: data.accentColor),
        ),
        const SizedBox(height: 32),
        // Tag
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: data.accentColor.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            data.tag,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              color: data.accentColor,
              letterSpacing: 1.8,
            ),
          ),
        ),
        const SizedBox(height: 14),
        Text(
          data.title,
          style: const TextStyle(
            fontSize: 34,
            fontWeight: FontWeight.w800,
            color: Colors.white,
            height: 1.1,
            letterSpacing: -0.6,
          ),
        ),
        const SizedBox(height: 18),
        Text(
          data.desc,
          style: TextStyle(
            fontSize: 15,
            color: Colors.white.withValues(alpha: 0.72),
            height: 1.65,
          ),
        ),
      ],
    );
  }
}

class _OBData {
  final IconData icon;
  final String tag, title, desc;
  final Color accentColor;
  const _OBData({
    required this.icon,
    required this.tag,
    required this.title,
    required this.desc,
    required this.accentColor,
  });
}
