import 'package:flutter/material.dart';
import '../models/auth_flow_mode.dart';
import '../models/user_role.dart';
import '../widgets/app_theme.dart';
import '../widgets/auth_flow_widgets.dart';
import 'login_screen.dart';
import 'register_screen.dart';

class RoleSelectionScreen extends StatefulWidget {
  final AuthFlowMode mode;
  const RoleSelectionScreen({super.key, this.mode = AuthFlowMode.login});

  @override
  State<RoleSelectionScreen> createState() => _RoleSelectionScreenState();
}

class _RoleSelectionScreenState extends State<RoleSelectionScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();
    _fadeAnimation = CurvedAnimation(parent: _controller, curve: Curves.easeIn);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final sp = authVerticalSpacing(context);
    return Scaffold(
      body: AuthGradientBackground(
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: AuthContentContainer(
              scrollable: true,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: sp * 0.4),
                  const BrandMark(size: 52, dark: true),
                  SizedBox(height: sp * 0.8),
                  Text(
                    widget.mode == AuthFlowMode.login ? 'Halo,\nselamat datang.' : 'Bergabung\nbersama kami.',
                    style: const TextStyle(
                      fontSize: 36, fontWeight: FontWeight.w800, color: Colors.white, height: 1.1, letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    widget.mode == AuthFlowMode.login
                        ? 'Pilih peranmu untuk memulai login.'
                        : 'Pilih peranmu untuk memulai pendaftaran.',
                    style: TextStyle(fontSize: 15, color: Colors.white.withValues(alpha: 0.7), height: 1.55),
                  ),
                  SizedBox(height: sp),
                  _RoleCard(
                    icon: Icons.search_rounded,
                    tag: 'CLIENT',
                    title: 'Saya Butuh Bantuan',
                    desc: 'Cari freelancer berbakat dan kelola proyek dengan mudah.',
                    onTap: () => _go(context, UserRole.client),
                  ),
                  const SizedBox(height: 14),
                  _RoleCard(
                    icon: Icons.work_rounded,
                    tag: 'FREELANCER',
                    title: 'Saya Bisa Bantu',
                    desc: 'Temukan proyek sesuai skill dan kembangkan karir freelance.',
                    onTap: () => _go(context, UserRole.freelancer),
                  ),
                  SizedBox(height: sp * 0.6),
                  Center(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (_) => RoleSelectionScreen(
                              mode: widget.mode == AuthFlowMode.login ? AuthFlowMode.register : AuthFlowMode.login,
                            ),
                          ),
                        );
                      },
                      child: Text(
                        widget.mode == AuthFlowMode.login ? 'Belum punya akun? Daftar' : 'Sudah punya akun? Masuk',
                        style: TextStyle(color: Colors.white.withValues(alpha: 0.65), fontSize: 14),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _go(BuildContext context, UserRole role) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => widget.mode == AuthFlowMode.login
            ? LoginScreen(selectedRole: role)
            : RegisterScreen(selectedRole: role),
      ),
    );
  }
}

class _RoleCard extends StatelessWidget {
  final IconData icon;
  final String tag, title, desc;
  final VoidCallback onTap;
  const _RoleCard({required this.icon, required this.tag, required this.title, required this.desc, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.09),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withValues(alpha: 0.14)),
        ),
        child: Row(
          children: [
            Container(
              width: 52, height: 52,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: Colors.white, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tag, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: Color(0x80FFFFFF), letterSpacing: 1.3)),
                  const SizedBox(height: 4),
                  Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white)),
                  const SizedBox(height: 4),
                  Text(desc, style: TextStyle(fontSize: 13, color: Colors.white.withValues(alpha: 0.65), height: 1.4)),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Container(
              width: 32, height: 32,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.arrow_forward_rounded, size: 16, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
