import 'package:flutter/material.dart';
import '../../utils/language_notifier.dart';
import '../../widgets/app_theme.dart';
import '../../widgets/app_animations.dart';
import 'freelancer_chat_room_screen.dart';

/// Chat List Screen Freelancer — "Pesan"
/// Filter tabs, chat items, typing indicator, FAB compose. Design: pic 5
class FreelancerChatListScreen extends StatefulWidget {
  const FreelancerChatListScreen({super.key});
  @override
  State<FreelancerChatListScreen> createState() => _FreelancerChatListScreenState();
}

class _FreelancerChatListScreenState extends State<FreelancerChatListScreen> {
  final _searchCtrl = TextEditingController();
  int _activeTab = 0;

  @override
  void initState() { super.initState(); LanguageNotifier.instance.addListener(_r); }
  @override
  void dispose() { LanguageNotifier.instance.removeListener(_r); _searchCtrl.dispose(); super.dispose(); }
  void _r() => setState(() {});

  final _tabs = const ['Semua', 'Belum Dibaca', 'Proyek Aktif'];

  List<_ChatData> get _chats => const [
    _ChatData(name: 'Andi Pratama', message: '', time: '10:45', unread: 0,
        isOnline: true, isTyping: true, avatarColor: Color(0xFF34495E)),
    _ChatData(name: 'Budi Santoso', message: 'Apakah file revisi desain UI suda…', time: '09:12',
        unread: 1, isOnline: false, isTyping: false, avatarColor: Color(0xFF2E7D5E), hasRead: false),
    _ChatData(name: 'Maya Putri', message: 'Terima kasih atas bantuannya, sa…', time: 'Kemarin',
        unread: 0, isOnline: false, isTyping: false, avatarColor: Color(0xFF1B5E40), hasRead: true),
    _ChatData(name: 'Citra Kirana', message: 'Halo, saya tertarik untuk kolaborasi …', time: 'Sabtu',
        unread: 0, isOnline: false, isTyping: false, avatarColor: Color(0xFF455A64)),
  ];

  @override
  Widget build(BuildContext context) {
    final isId = LanguageNotifier.instance.isIndonesian;

    return Scaffold(
      backgroundColor: FPal.bg,
      // FAB compose
      floatingActionButton: BounceIn(
        delay: const Duration(milliseconds: 800),
        child: FloatingActionButton(
          onPressed: () {},
          backgroundColor: FPal.primary,
          child: const Icon(Icons.edit_rounded, color: Colors.white, size: 22),
        ),
      ),
      body: SafeArea(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // ═══ APP BAR ═══
          SlideInLeft(duration: const Duration(milliseconds: 600),
            child: Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Row(children: [
                Container(width: 38, height: 38, decoration: BoxDecoration(shape: BoxShape.circle,
                    border: Border.all(color: FPal.primary, width: 2)),
                    child: ClipOval(child: Container(color: FPal.primaryLight,
                        child: const Icon(Icons.person, color: FPal.primary, size: 20)))),
                const SizedBox(width: 12),
                const Text('SkillBantuin', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800,
                    color: FPal.ink, letterSpacing: -0.3)),
                const SizedBox(width: 8),
                const Icon(Icons.qr_code_scanner_rounded, color: FPal.ink, size: 20),
                const Spacer(),
                const Icon(Icons.notifications_outlined, color: FPal.ink, size: 22),
              ]))),
          const SizedBox(height: 12),
          Container(height: 2, color: FPal.primaryLight),
          const SizedBox(height: 18),

          // ═══ TITLE + SUBTITLE ═══
          Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
            child: BounceIn(delay: const Duration(milliseconds: 150),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(isId ? 'Pesan' : 'Messages',
                    style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: FPal.ink)),
                const SizedBox(height: 4),
                Text(isId ? 'Kelola percakapan proyek Anda' : 'Manage your project conversations',
                    style: const TextStyle(fontSize: 14, color: FPal.inkMuted, fontWeight: FontWeight.w500)),
              ]))),
          const SizedBox(height: 16),

          // ═══ SEARCH BAR ═══
          SlideUp(delay: const Duration(milliseconds: 250),
            child: Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFFDDE2EE))),
                child: TextField(controller: _searchCtrl,
                  decoration: InputDecoration(
                    hintText: isId ? 'Cari percakapan...' : 'Search conversations...',
                    hintStyle: const TextStyle(color: FPal.inkMuted, fontSize: 14, fontWeight: FontWeight.w500),
                    prefixIcon: const Icon(Icons.search_rounded, color: FPal.inkMuted, size: 22),
                    border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(vertical: 14),
                  )),
              ))),
          const SizedBox(height: 14),

          // ═══ FILTER TABS ═══
          SizedBox(height: 40, child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            itemCount: _tabs.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (context, i) {
              final isActive = i == _activeTab;
              return SlideInLeft(
                delay: Duration(milliseconds: 300 + i * 80),
                duration: const Duration(milliseconds: 400),
                child: GestureDetector(
                  onTap: () => setState(() => _activeTab = i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250), curve: Curves.easeOut,
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                    decoration: BoxDecoration(
                      color: isActive ? FPal.primary : Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: isActive ? FPal.primary : const Color(0xFFDDE2EE)),
                    ),
                    child: Text(_tabs[i], style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700,
                        color: isActive ? Colors.white : FPal.inkSoft)),
                  ),
                ),
              );
            },
          )),
          const SizedBox(height: 12),

          // ═══ CHAT LIST ═══
          Expanded(child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            itemCount: _chats.length,
            itemBuilder: (context, i) => SlideInRight(
              delay: Duration(milliseconds: 400 + i * 100),
              duration: const Duration(milliseconds: 450),
              child: _ChatItem(data: _chats[i], onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => FreelancerChatRoomScreen(
                      name: _chats[i].name, isOnline: _chats[i].isOnline, avatarColor: _chats[i].avatarColor)))),
            ),
          )),
        ]),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
class _ChatData {
  final String name, message, time;
  final int unread;
  final bool isOnline, isTyping;
  final Color avatarColor;
  final bool hasRead;
  const _ChatData({required this.name, required this.message, required this.time,
      required this.unread, required this.isOnline, required this.isTyping,
      required this.avatarColor, this.hasRead = false});
}

class _ChatItem extends StatelessWidget {
  final _ChatData data;
  final VoidCallback onTap;
  const _ChatItem({required this.data, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      TapScale(onTap: onTap, child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Row(children: [
          // Avatar + online dot
          Stack(children: [
            Container(width: 52, height: 52, decoration: BoxDecoration(shape: BoxShape.circle,
                color: data.avatarColor.withOpacity(0.12),
                border: Border.all(color: data.avatarColor.withOpacity(0.25), width: 1.5)),
                child: Icon(Icons.person, color: data.avatarColor, size: 26)),
            if (data.isOnline) Positioned(bottom: 2, left: 2,
                child: Container(width: 12, height: 12, decoration: BoxDecoration(shape: BoxShape.circle,
                    color: FPal.success, border: Border.all(color: Colors.white, width: 2)))),
          ]),
          const SizedBox(width: 14),
          // Content
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text(data.name, style: TextStyle(fontSize: 15,
                  fontWeight: data.unread > 0 ? FontWeight.w900 : FontWeight.w700, color: FPal.ink)),
              Text(data.time, style: TextStyle(fontSize: 12,
                  fontWeight: data.unread > 0 ? FontWeight.w700 : FontWeight.w500,
                  color: data.unread > 0 ? FPal.primary : FPal.inkMuted)),
            ]),
            const SizedBox(height: 4),
            Row(children: [
              // Double-check untuk pesan yang sudah dibaca
              if (data.hasRead) ...[
                Icon(Icons.done_all_rounded, size: 16, color: FPal.primary),
                const SizedBox(width: 4),
              ],
              Expanded(child: data.isTyping
                  ? Text('Sedang mengetik…', style: TextStyle(fontSize: 13,
                      fontWeight: FontWeight.w600, color: FPal.success, fontStyle: FontStyle.italic))
                  : Text(data.message, maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 13,
                          fontWeight: data.unread > 0 ? FontWeight.w600 : FontWeight.w500,
                          color: data.unread > 0 ? FPal.ink : FPal.inkMuted))),
              if (data.unread > 0) ...[
                const SizedBox(width: 8),
                Container(width: 22, height: 22, decoration: const BoxDecoration(shape: BoxShape.circle, color: FPal.primary),
                    child: Center(child: Text(data.unread.toString(),
                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white)))),
              ],
            ]),
          ])),
        ]),
      )),
      Container(height: 1, color: const Color(0xFFF0EDE8)),
    ]);
  }
}
