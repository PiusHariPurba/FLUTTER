import 'package:flutter/material.dart';
import '../../utils/language_notifier.dart';
import '../../widgets/app_theme.dart';
import '../../widgets/app_animations.dart';

/// Profile Screen Freelancer — avatar, stats, settings, logout.
/// Design: pic 7
class FreelancerProfileScreen extends StatefulWidget {
  const FreelancerProfileScreen({super.key});
  @override
  State<FreelancerProfileScreen> createState() => _FreelancerProfileScreenState();
}

class _FreelancerProfileScreenState extends State<FreelancerProfileScreen> {
  bool _darkMode = false;

  @override
  void initState() { super.initState(); LanguageNotifier.instance.addListener(_r); }
  @override
  void dispose() { LanguageNotifier.instance.removeListener(_r); super.dispose(); }
  void _r() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final isId = LanguageNotifier.instance.isIndonesian;

    return Scaffold(
      backgroundColor: FPal.bg,
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            // ═══ APP BAR ═══
            SlideInLeft(duration: const Duration(milliseconds: 600),
              child: Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: Row(children: [
                  Container(width: 38, height: 38, decoration: BoxDecoration(shape: BoxShape.circle,
                      border: Border.all(color: FPal.primary, width: 2)),
                      child: ClipOval(child: Container(color: FPal.primaryLight,
                          child: const Icon(Icons.person, color: FPal.primary, size: 20)))),
                  const SizedBox(width: 12),
                  const Text('SkillBantuin', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800,
                      color: FPal.ink, letterSpacing: -0.3)),
                  const Spacer(),
                  const Icon(Icons.notifications_outlined, color: FPal.ink, size: 22),
                ]))),
            const SizedBox(height: 12),
            Container(height: 2, color: FPal.primaryLight),
            const SizedBox(height: 24),

            // ═══ PROFILE CARD ═══
            BounceIn(delay: const Duration(milliseconds: 150), duration: const Duration(milliseconds: 800),
              child: Column(children: [
                // Avatar besar + verified badge
                Stack(alignment: Alignment.center, children: [
                  // Ring teal border
                  Container(width: 100, height: 100, decoration: BoxDecoration(shape: BoxShape.circle,
                      border: Border.all(color: FPal.primary, width: 3))),
                  // Avatar
                  Container(width: 88, height: 88, decoration: BoxDecoration(shape: BoxShape.circle,
                      color: FPal.primaryLight),
                      child: const Icon(Icons.person, color: FPal.primary, size: 44)),
                  // Verified badge
                  Positioned(bottom: 0, right: 0,
                      child: Container(width: 30, height: 30, decoration: BoxDecoration(shape: BoxShape.circle,
                          color: FPal.primary, border: Border.all(color: Colors.white, width: 2.5)),
                          child: const Icon(Icons.verified_rounded, color: Colors.white, size: 16))),
                ]),
                const SizedBox(height: 16),
                // Nama
                const Text('Siti Aminah', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: FPal.ink)),
                const SizedBox(height: 8),
                // Verified Freelancer badge
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  decoration: BoxDecoration(color: FPal.primaryLight, borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: FPal.primary.withOpacity(0.3))),
                  child: const Text('Verified Freelancer', style: TextStyle(fontSize: 13,
                      fontWeight: FontWeight.w700, color: FPal.primary)),
                ),
                const SizedBox(height: 16),
                // Edit Profile button (outlined)
                GestureDetector(onTap: () {},
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: FPal.primary, width: 1.5)),
                    child: Text(isId ? 'Edit\nProfile' : 'Edit\nProfile', textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: FPal.primary, height: 1.2)),
                  ),
                ),
              ])),
            const SizedBox(height: 24),

            // ═══ STATS ROW ═══
            Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
              child: FadeScaleIn(delay: const Duration(milliseconds: 300),
                child: Row(children: [
                  _StatCard(value: '24', label: isId ? 'Proyek Selesai' : 'Completed'),
                  const SizedBox(width: 10),
                  _StatCard(value: '4.9', label: 'Rating', showStar: true),
                  const SizedBox(width: 10),
                  _StatCard(value: '18', label: isId ? 'Ulasan' : 'Reviews'),
                ]))),
            const SizedBox(height: 28),

            // ═══ SETTINGS LIST ═══
            Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
              child: SlideUp(delay: const Duration(milliseconds: 450),
                child: Container(
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8, offset: const Offset(0, 2))]),
                  child: Column(children: [
                    // Personal Information
                    _SettingsTile(icon: Icons.person_outline_rounded, iconBg: FPal.primaryLight,
                        title: 'Personal Information', onTap: () {}),
                    Container(height: 1, margin: const EdgeInsets.symmetric(horizontal: 16), color: const Color(0xFFF0EDE8)),

                    // Language / Bahasa
                    _SettingsTile(icon: Icons.language_rounded, iconBg: FPal.primaryLight,
                        title: 'Language / Bahasa',
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          GestureDetector(onTap: () => LanguageNotifier.instance.setLanguage('id'),
                            child: Container(width: 28, height: 28, decoration: BoxDecoration(shape: BoxShape.circle,
                                color: isId ? FPal.primaryLight : FPal.bgMuted,
                                border: Border.all(color: isId ? FPal.primary : const Color(0xFFDDE2EE), width: isId ? 2 : 1)),
                                child: const Center(child: Text('🇮🇩', style: TextStyle(fontSize: 14))))),
                          const SizedBox(width: 6),
                          GestureDetector(onTap: () => LanguageNotifier.instance.setLanguage('en'),
                            child: Container(width: 28, height: 28, decoration: BoxDecoration(shape: BoxShape.circle,
                                color: !isId ? FPal.primaryLight : FPal.bgMuted,
                                border: Border.all(color: !isId ? FPal.primary : const Color(0xFFDDE2EE), width: !isId ? 2 : 1)),
                                child: const Center(child: Text('🇺🇸', style: TextStyle(fontSize: 14))))),
                          const SizedBox(width: 4),
                          const Icon(Icons.chevron_right_rounded, color: FPal.inkMuted, size: 22),
                        ])),
                    Container(height: 1, margin: const EdgeInsets.symmetric(horizontal: 16), color: const Color(0xFFF0EDE8)),

                    // Dark Mode
                    _SettingsTile(icon: Icons.dark_mode_outlined, iconBg: FPal.primaryLight,
                        title: 'Dark Mode',
                        trailing: Switch(value: _darkMode,
                            onChanged: (v) => setState(() => _darkMode = v),
                            activeColor: FPal.primary, inactiveTrackColor: const Color(0xFFDDE2EE))),
                    Container(height: 1, margin: const EdgeInsets.symmetric(horizontal: 16), color: const Color(0xFFF0EDE8)),

                    // Help Center
                    _SettingsTile(icon: Icons.help_outline_rounded, iconBg: FPal.primaryLight,
                        title: 'Help Center', onTap: () {}),
                  ]),
                ))),
            const SizedBox(height: 28),

            // ═══ LOG OUT ═══
            Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
              child: SlideUp(delay: const Duration(milliseconds: 550),
                child: GestureDetector(onTap: () {},
                  child: Container(
                    width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(color: const Color(0xFFFDE8E8), borderRadius: BorderRadius.circular(14)),
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.logout_rounded, color: FPal.danger, size: 20),
                      const SizedBox(width: 8),
                      Text('Log Out', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: FPal.danger)),
                    ]),
                  )))),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
class _StatCard extends StatelessWidget {
  final String value, label;
  final bool showStar;
  const _StatCard({required this.value, required this.label, this.showStar = false});

  @override
  Widget build(BuildContext context) {
    return Expanded(child: Container(
      padding: const EdgeInsets.symmetric(vertical: 18),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFE8E5E0)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8, offset: const Offset(0, 2))]),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          if (showStar) ...[
            const Icon(Icons.star_rounded, color: Color(0xFFFFA726), size: 18),
            const SizedBox(width: 4),
          ],
          Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: FPal.primary)),
        ]),
        const SizedBox(height: 4),
        Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11,
            fontWeight: FontWeight.w600, color: FPal.inkMuted)),
      ]),
    ));
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final Color iconBg;
  final String title;
  final VoidCallback? onTap;
  final Widget? trailing;
  const _SettingsTile({required this.icon, required this.iconBg, required this.title, this.onTap, this.trailing});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(onTap: onTap, behavior: HitTestBehavior.opaque,
      child: Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(children: [
          Container(width: 36, height: 36,
              decoration: BoxDecoration(color: iconBg, borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: FPal.primary, size: 20)),
          const SizedBox(width: 14),
          Expanded(child: Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: FPal.ink))),
          trailing ?? const Icon(Icons.chevron_right_rounded, color: FPal.inkMuted, size: 22),
        ])),
    );
  }
}
