import 'package:flutter/material.dart';
import '../../utils/language_notifier.dart';
import '../../widgets/app_theme.dart';
import '../../widgets/app_animations.dart';
import 'freelancer_filter_screen.dart';

/// Search/Explore Screen Freelancer — pencarian terakhir, kategori populer,
/// rekomendasi pekerjaan. Design: pic 2
class FreelancerSearchScreen extends StatefulWidget {
  const FreelancerSearchScreen({super.key});
  @override
  State<FreelancerSearchScreen> createState() => _FreelancerSearchScreenState();
}

class _FreelancerSearchScreenState extends State<FreelancerSearchScreen> {
  final _searchCtrl = TextEditingController();

  final _recentSearches = const ['UI UX Designer', 'Copywriter', 'React Developer'];

  final _categories = const [
    _CatData(Icons.palette_rounded, 'Design'),
    _CatData(Icons.code_rounded, 'Programming'),
    _CatData(Icons.campaign_rounded, 'Marketing'),
    _CatData(Icons.edit_note_rounded, 'Writing'),
  ];

  List<_RecommendData> get _recommendations => const [
    _RecommendData(icon: Icons.design_services_rounded, iconBg: Color(0xFFEDE9FE),
        title: 'Senior Product Designer', company: 'TechVantage Solusi', location: 'Jakarta',
        tags: ['Remote', 'Full-time'], salary: 'Rp 12jt – 18jt / bln', timeAgo: '2 hari yang lalu'),
    _RecommendData(icon: Icons.create_rounded, iconBg: Color(0xFFE0F2FE),
        title: 'Creative Copywriter', company: 'MediaGlow Agency', location: 'Bandung',
        tags: ['Hybrid', 'Freelance'], salary: 'Rp 8jt – 12jt / bln', timeAgo: '5 jam yang lalu'),
  ];

  @override
  void dispose() { _searchCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final isId = LanguageNotifier.instance.isIndonesian;

    return Scaffold(
      backgroundColor: FPal.bg,
      // App bar: back + search field + filter icon
      appBar: AppBar(
        backgroundColor: FPal.bg, elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back_rounded, color: FPal.ink),
            onPressed: () => Navigator.pop(context)),
        titleSpacing: 0,
        title: Container(
          height: 42,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(color: const Color(0xFFF2F1EE), borderRadius: BorderRadius.circular(22)),
          child: Row(children: [
            const Icon(Icons.search_rounded, color: FPal.inkMuted, size: 20),
            const SizedBox(width: 8),
            Expanded(child: TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: isId ? 'Cari freelance atau proyek...' : 'Search freelance or projects...',
                hintStyle: const TextStyle(color: FPal.inkMuted, fontSize: 14, fontWeight: FontWeight.w500),
                border: InputBorder.none, isDense: true, contentPadding: EdgeInsets.zero,
              ), style: const TextStyle(fontSize: 14, color: FPal.ink),
            )),
          ]),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.tune_rounded, color: FPal.ink, size: 22),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FreelancerFilterScreen())),
          ),
        ],
      ),

      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 30),
        children: [
          // ═══ PENCARIAN TERAKHIR ═══
          SlideUp(
            delay: const Duration(milliseconds: 100),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text(isId ? 'Pencarian Terakhir' : 'Recent Searches',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: FPal.ink)),
              GestureDetector(onTap: () {},
                  child: Text(isId ? 'Hapus Semua' : 'Clear All',
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: FPal.primary))),
            ]),
          ),
          const SizedBox(height: 12),
          // Recent search chips
          Wrap(spacing: 10, runSpacing: 10,
            children: List.generate(_recentSearches.length, (i) => SlideInLeft(
                  delay: Duration(milliseconds: 150 + i * 80),
                  duration: const Duration(milliseconds: 400),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: const Color(0xFFDDE2EE))),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.history_rounded, color: FPal.inkMuted, size: 16),
                      const SizedBox(width: 6),
                      Text(_recentSearches[i], style: const TextStyle(fontSize: 13,
                          fontWeight: FontWeight.w600, color: FPal.ink)),
                    ]),
                  ),
                )),
          ),
          const SizedBox(height: 28),

          // ═══ KATEGORI POPULER — 2×2 grid ═══
          SlideUp(
            delay: const Duration(milliseconds: 300),
            child: Text(isId ? 'Kategori Populer' : 'Popular Categories',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: FPal.ink)),
          ),
          const SizedBox(height: 14),
          GridView.count(
            crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.6,
            children: List.generate(_categories.length, (i) => BounceIn(
                  delay: Duration(milliseconds: 350 + i * 100),
                  child: TapScale(
                    onTap: () {},
                    child: Container(
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFFE8E5E0))),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(_categories[i].icon, color: FPal.primary, size: 28),
                        const SizedBox(height: 8),
                        Text(_categories[i].label, style: const TextStyle(fontSize: 14,
                            fontWeight: FontWeight.w700, color: FPal.ink)),
                      ]),
                    ),
                  ),
                )),
          ),
          const SizedBox(height: 28),

          // ═══ REKOMENDASI UNTUKMU ═══
          SlideUp(
            delay: const Duration(milliseconds: 600),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text(isId ? 'Rekomendasi Untukmu' : 'Recommended for You',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: FPal.ink)),
              GestureDetector(onTap: () {},
                  child: Text(isId ? 'Lihat Semua' : 'See All',
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: FPal.primary))),
            ]),
          ),
          const SizedBox(height: 14),

          // Recommendation cards
          ...List.generate(_recommendations.length, (i) => SlideInRight(
                delay: Duration(milliseconds: 700 + i * 130),
                duration: const Duration(milliseconds: 550),
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: _RecommendCard(data: _recommendations[i]),
                ),
              )),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
class _CatData {
  final IconData icon;
  final String label;
  const _CatData(this.icon, this.label);
}

class _RecommendData {
  final IconData icon;
  final Color iconBg;
  final String title, company, location, salary, timeAgo;
  final List<String> tags;
  const _RecommendData({required this.icon, required this.iconBg, required this.title,
      required this.company, required this.location, required this.tags,
      required this.salary, required this.timeAgo});
}

class _RecommendCard extends StatelessWidget {
  final _RecommendData data;
  const _RecommendCard({required this.data});

  @override
  Widget build(BuildContext context) {
    return TapScale(
      onTap: () {},
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 12, offset: const Offset(0, 4))]),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(width: 42, height: 42,
                decoration: BoxDecoration(color: data.iconBg, borderRadius: BorderRadius.circular(12)),
                child: Icon(data.icon, color: FPal.primary, size: 20)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(data.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: FPal.ink)),
              const SizedBox(height: 3),
              Text('${data.company} • ${data.location}',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: FPal.inkMuted)),
            ])),
            const Icon(Icons.bookmark_outline_rounded, color: FPal.inkMuted, size: 22),
          ]),
          const SizedBox(height: 12),
          // Tags
          Wrap(spacing: 8, children: data.tags.map((t) => Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(color: FPal.bgMuted, borderRadius: BorderRadius.circular(6)),
                child: Text(t, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: FPal.inkSoft)),
              )).toList()),
          const SizedBox(height: 12),
          Container(height: 1, color: const Color(0xFFEEECE8)),
          const SizedBox(height: 12),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(data.salary, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: FPal.primary)),
            Text(data.timeAgo, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: FPal.inkMuted)),
          ]),
        ]),
      ),
    );
  }
}
