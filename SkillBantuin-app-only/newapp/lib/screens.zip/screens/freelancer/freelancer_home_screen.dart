import 'package:flutter/material.dart';
import '../../utils/language_notifier.dart';
import '../../widgets/app_theme.dart';
import '../../widgets/app_animations.dart';
import 'freelancer_search_screen.dart';

/// Home Screen Freelancer — "Find your next project."
/// Job feed: search bar, filter pills, job cards + Apply, FAB
/// Design: pic 1
class FreelancerHomeScreen extends StatefulWidget {
  const FreelancerHomeScreen({super.key});
  @override
  State<FreelancerHomeScreen> createState() => _FreelancerHomeScreenState();
}

class _FreelancerHomeScreenState extends State<FreelancerHomeScreen> {
  int _activeFilter = 0;

  @override
  void initState() { super.initState(); LanguageNotifier.instance.addListener(_r); }
  @override
  void dispose() { LanguageNotifier.instance.removeListener(_r); super.dispose(); }
  void _r() => setState(() {});

  final _filters = const ['All', 'Remote', 'Full-time', 'Internship'];

  List<_JobData> get _jobs => const [
    _JobData(icon: Icons.dashboard_rounded, iconBg: Color(0xFFE0F2FE),
        title: 'UI/UX Designer for Fintech App', company: 'Digital Solution', location: 'Jakarta, Remote',
        tags: ['High Priority', 'Design'], tagColors: [Color(0xFFD1FAE5), Color(0xFFF2F1EE)],
        tagTextColors: [Color(0xFF059669), Color(0xFF5C5855)],
        budgetLabel: 'BUDGET RANGE', budget: 'Rp 5M – 8M'),
    _JobData(icon: Icons.article_rounded, iconBg: Color(0xFFE0F2FE),
        title: 'Blog Article Writer', company: 'TechMedia', location: 'Remote',
        tags: ['Contract', 'Content'], tagColors: [Color(0xFFFEE2E2), Color(0xFFF2F1EE)],
        tagTextColors: [Color(0xFFDC2626), Color(0xFF5C5855)],
        budgetLabel: 'BUDGET', budget: 'Rp 200k/article'),
    _JobData(icon: Icons.code_rounded, iconBg: Color(0xFFE0F2FE),
        title: 'React Developer', company: 'Startup Co', location: 'Hybrid',
        tags: ['Urgent', 'Development'], tagColors: [Color(0xFFFEE2E2), Color(0xFFF2F1EE)],
        tagTextColors: [Color(0xFFDC2626), Color(0xFF5C5855)],
        budgetLabel: 'BUDGET', budget: 'Rp 15M/project'),
  ];

  void _goSearch() => Navigator.push(context, MaterialPageRoute(builder: (_) => const FreelancerSearchScreen()));

  @override
  Widget build(BuildContext context) {
    final isId = LanguageNotifier.instance.isIndonesian;

    return Scaffold(
      backgroundColor: FPal.bg,
      // FAB — tombol "+" hijau kanan bawah
      floatingActionButton: BounceIn(
        delay: const Duration(milliseconds: 1000),
        child: FloatingActionButton(
          onPressed: () {},
          backgroundColor: FPal.primary,
          child: const Icon(Icons.add_rounded, color: Colors.white, size: 28),
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            // ═══ APP BAR ═══
            SlideInLeft(
              duration: const Duration(milliseconds: 600),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: Row(children: [
                  // Logo hijau "SkillBantuin"
                  const Text('SkillBantuin', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900,
                      color: FPal.primary, letterSpacing: -0.3)),
                  const Spacer(),
                  // Search icon
                  GestureDetector(
                    onTap: _goSearch,
                    child: const Icon(Icons.search_rounded, color: FPal.ink, size: 24),
                  ),
                  const SizedBox(width: 14),
                  // Avatar
                  BounceIn(
                    delay: const Duration(milliseconds: 300),
                    child: Container(width: 38, height: 38,
                        decoration: BoxDecoration(shape: BoxShape.circle,
                            border: Border.all(color: FPal.primary, width: 2)),
                        child: ClipOval(child: Container(color: FPal.primaryLight,
                            child: const Icon(Icons.person, color: FPal.primary, size: 20)))),
                  ),
                ]),
              ),
            ),
            const SizedBox(height: 12),
            // Garis hijau muda separator
            Container(height: 2, color: FPal.primaryLight),
            const SizedBox(height: 20),

            // ═══ HERO TEXT — "Find your next project." ═══
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: BounceIn(
                delay: const Duration(milliseconds: 150),
                duration: const Duration(milliseconds: 900),
                child: Text(
                  isId ? 'Temukan proyek\nberikutnya.' : 'Find your next\nproject.',
                  style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900,
                      color: FPal.ink, height: 1.15, letterSpacing: -0.5),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // ═══ SEARCH BAR ═══
            SlideUp(
              delay: const Duration(milliseconds: 300),
              distance: 0.2,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: GestureDetector(
                  onTap: _goSearch,
                  child: Container(
                    height: 52,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.white, borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0xFFDDE2EE)),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04),
                          blurRadius: 8, offset: const Offset(0, 2))],
                    ),
                    child: Row(children: [
                      const Icon(Icons.search_rounded, color: FPal.inkMuted, size: 22),
                      const SizedBox(width: 10),
                      Expanded(child: Text(isId ? 'Cari pekerjaan atau skill...' : 'Search jobs or skills...',
                          style: const TextStyle(color: FPal.inkMuted, fontSize: 14, fontWeight: FontWeight.w500))),
                      // Filter icon
                      const Icon(Icons.tune_rounded, color: FPal.ink, size: 22),
                    ]),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 18),

            // ═══ FILTER PILLS — horizontal scroll ═══
            SizedBox(
              height: 40,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: _filters.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (context, i) {
                  final isActive = i == _activeFilter;
                  return SlideInLeft(
                    delay: Duration(milliseconds: 400 + i * 80),
                    duration: const Duration(milliseconds: 400),
                    child: GestureDetector(
                      onTap: () => setState(() => _activeFilter = i),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 250), curve: Curves.easeOut,
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        decoration: BoxDecoration(
                          color: isActive ? FPal.primary : Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: isActive ? FPal.primary : const Color(0xFFDDE2EE)),
                        ),
                        child: Text(_filters[i], style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700,
                            color: isActive ? Colors.white : FPal.inkSoft)),
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 20),

            // ═══ JOB CARDS — slide dari kanan staggered ═══
            ...List.generate(_jobs.length, (i) => SlideInRight(
                  delay: Duration(milliseconds: 550 + i * 130),
                  duration: const Duration(milliseconds: 550),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                    child: _JobCard(data: _jobs[i], isId: isId),
                  ),
                )),
            const SizedBox(height: 80), // Space untuk FAB
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
class _JobData {
  final IconData icon;
  final Color iconBg;
  final String title, company, location, budgetLabel, budget;
  final List<String> tags;
  final List<Color> tagColors, tagTextColors;
  const _JobData({required this.icon, required this.iconBg, required this.title,
      required this.company, required this.location, required this.tags,
      required this.tagColors, required this.tagTextColors,
      required this.budgetLabel, required this.budget});
}

class _JobCard extends StatelessWidget {
  final _JobData data;
  final bool isId;
  const _JobCard({required this.data, required this.isId});

  @override
  Widget build(BuildContext context) {
    return TapScale(
      onTap: () {},
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 12, offset: const Offset(0, 4))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Row: Icon + Title + Bookmark
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Icon container
            Container(width: 44, height: 44,
                decoration: BoxDecoration(color: data.iconBg, borderRadius: BorderRadius.circular(12)),
                child: Icon(data.icon, color: FPal.primary, size: 22)),
            const SizedBox(width: 14),
            // Title + Company
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(data.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800,
                  color: FPal.ink, height: 1.2)),
              const SizedBox(height: 4),
              Text('${data.company} • ${data.location}',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: FPal.inkMuted)),
            ])),
            const SizedBox(width: 8),
            // Bookmark icon
            const Icon(Icons.bookmark_outline_rounded, color: FPal.inkMuted, size: 24),
          ]),
          const SizedBox(height: 14),

          // Tags
          Wrap(spacing: 8, runSpacing: 8,
            children: List.generate(data.tags.length, (i) => Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(color: data.tagColors[i], borderRadius: BorderRadius.circular(8)),
                  child: Text(data.tags[i], style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700,
                      color: data.tagTextColors[i])),
                )),
          ),
          const SizedBox(height: 16),

          // Budget + Apply button
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(data.budgetLabel, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700,
                  color: FPal.inkMuted, letterSpacing: 0.8)),
              const SizedBox(height: 2),
              Text(data.budget, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900,
                  color: FPal.primary)),
            ]),
            // Apply button
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              decoration: BoxDecoration(color: FPal.primary, borderRadius: BorderRadius.circular(12),
                  boxShadow: [BoxShadow(color: FPal.primary.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 3))]),
              child: const Text('Apply', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
            ),
          ]),
        ]),
      ),
    );
  }
}
