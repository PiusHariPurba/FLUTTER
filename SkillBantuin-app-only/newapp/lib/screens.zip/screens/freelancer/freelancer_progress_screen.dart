import 'package:flutter/material.dart';
import '../../utils/language_notifier.dart';
import '../../widgets/app_theme.dart';
import '../../widgets/app_animations.dart';

/// Progress Screen Freelancer — "Progres Pekerjaan"
/// Stats, ongoing projects, activity timeline. Design: pic 4
class FreelancerProgressScreen extends StatefulWidget {
  const FreelancerProgressScreen({super.key});
  @override
  State<FreelancerProgressScreen> createState() => _FreelancerProgressScreenState();
}

class _FreelancerProgressScreenState extends State<FreelancerProgressScreen> {
  @override
  void initState() { super.initState(); LanguageNotifier.instance.addListener(_r); }
  @override
  void dispose() { LanguageNotifier.instance.removeListener(_r); super.dispose(); }
  void _r() => setState(() {});

  List<_ProjectData> get _projects => const [
    _ProjectData(title: 'Desain UI/UX Mobile App', client: 'Andi Pratama', progress: 0.75,
        status: 'On Track', statusColor: Color(0xFF1A6B55), statusBg: Color(0xFFD1FAE5),
        deadline: 'Selesai dalam 3 hari'),
    _ProjectData(title: 'Pengembangan Backend API', client: 'Budi Santoso', progress: 0.40,
        status: 'Revision Requested', statusColor: Color(0xFFB8860B), statusBg: Color(0xFFFEF3C7),
        deadline: 'Perlu tindakan segera'),
  ];

  List<_ActivityData> get _activities => [
    _ActivityData(category: 'Feedback Klien', catColor: FPal.primary,
        text: 'Budi Santoso memberikan komentar pada API Documentation.',
        boldParts: ['Budi Santoso'], time: '2 jam yang lalu', dotColor: FPal.primary),
    _ActivityData(category: 'Pengumpulan Tugas', catColor: FPal.inkSoft,
        text: 'Anda telah mengunggah desain UI High-Fidelity untuk Andi Pratama.',
        boldParts: ['Andi Pratama'], time: 'Kemarin, 14:20', dotColor: FPal.inkMuted),
    _ActivityData(category: 'Status Proyek', catColor: FPal.inkSoft,
        text: 'Proyek "Landing Page Revamp" ditandai selesai oleh klien.',
        boldParts: ['"Landing Page Revamp"'], time: '3 hari yang lalu', dotColor: FPal.inkMuted),
  ];

  @override
  Widget build(BuildContext context) {
    final isId = LanguageNotifier.instance.isIndonesian;

    return Scaffold(
      backgroundColor: FPal.bg,
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            // ═══ APP BAR ═══
            SlideInLeft(duration: const Duration(milliseconds: 600),
              child: Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: Row(children: [
                  Container(width: 38, height: 38, decoration: BoxDecoration(shape: BoxShape.circle,
                      border: Border.all(color: FPal.primary, width: 2)),
                      child: ClipOval(child: Container(color: FPal.primaryLight,
                          child: const Icon(Icons.person, color: FPal.primary, size: 20)))),
                  const SizedBox(width: 12),
                  const Text('SkillBantuin', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800,
                      color: FPal.ink, letterSpacing: -0.3)),
                  const Spacer(),
                  const Icon(Icons.notifications_outlined, color: FPal.ink, size: 22),
                ]))),
            const SizedBox(height: 12),
            Container(height: 2, color: FPal.primaryLight),
            const SizedBox(height: 20),

            // ═══ TITLE ═══
            Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
              child: BounceIn(delay: const Duration(milliseconds: 150), duration: const Duration(milliseconds: 900),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(isId ? 'Progres Pekerjaan' : 'Work Progress',
                      style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: FPal.ink, height: 1.1)),
                  const SizedBox(height: 6),
                  Text(isId ? 'Pantau status tugas dan tenggat waktu Anda' : 'Monitor your tasks and deadlines',
                      style: const TextStyle(fontSize: 14, color: FPal.inkMuted, fontWeight: FontWeight.w500)),
                ]))),
            const SizedBox(height: 22),

            // ═══ STATS CARDS ═══
            Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
              child: BounceIn(delay: const Duration(milliseconds: 250), duration: const Duration(milliseconds: 800),
                child: Row(children: [
                  // Pekerjaan Aktif
                  Expanded(child: Container(padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFFE8E5E0))),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Container(width: 34, height: 34,
                            decoration: BoxDecoration(color: FPal.bgMuted, borderRadius: BorderRadius.circular(10)),
                            child: const Icon(Icons.calendar_today_rounded, color: FPal.ink, size: 18)),
                        const SizedBox(height: 12),
                        Text(isId ? 'Pekerjaan Aktif' : 'Active Jobs',
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: FPal.inkMuted)),
                        const SizedBox(height: 2),
                        const AnimatedCounter(value: 5, style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: FPal.ink)),
                      ]))),
                  const SizedBox(width: 14),
                  // Tenggat Terdekat
                  Expanded(child: Container(padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFFE8E5E0))),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Container(width: 34, height: 34,
                            decoration: BoxDecoration(color: FPal.bgMuted, borderRadius: BorderRadius.circular(10)),
                            child: const Icon(Icons.timer_rounded, color: FPal.ink, size: 18)),
                        const SizedBox(height: 12),
                        Text(isId ? 'Tenggat Terdekat' : 'Due Soon',
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: FPal.inkMuted)),
                        const SizedBox(height: 2),
                        const AnimatedCounter(value: 2, style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: FPal.ink)),
                      ]))),
                ]))),
            const SizedBox(height: 28),

            // ═══ PROYEK SEDANG BERJALAN ═══
            Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
              child: SlideUp(delay: const Duration(milliseconds: 400),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text(isId ? 'Proyek Sedang Berjalan' : 'Ongoing Projects',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: FPal.ink)),
                  Text(isId ? 'Lihat Semua' : 'See All',
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: FPal.primary)),
                ]))),
            const SizedBox(height: 14),

            // Project cards
            ...List.generate(_projects.length, (i) => SlideInRight(
                  delay: Duration(milliseconds: 500 + i * 150),
                  duration: const Duration(milliseconds: 550),
                  child: Padding(padding: const EdgeInsets.fromLTRB(20, 0, 20, 14),
                    child: _ProjectCard(data: _projects[i], isId: isId)))),
            const SizedBox(height: 24),

            // ═══ AKTIVITAS TERBARU ═══
            Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
              child: SlideUp(delay: const Duration(milliseconds: 700),
                child: Text(isId ? 'Aktivitas Terbaru' : 'Recent Activity',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: FPal.ink)))),
            const SizedBox(height: 16),

            // Activity timeline
            Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(children: List.generate(_activities.length, (i) => SlideInLeft(
                    delay: Duration(milliseconds: 800 + i * 120),
                    duration: const Duration(milliseconds: 500),
                    child: _ActivityItem(data: _activities[i], isLast: i == _activities.length - 1))))),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
class _ProjectData {
  final String title, client, status, deadline;
  final double progress;
  final Color statusColor, statusBg;
  const _ProjectData({required this.title, required this.client, required this.progress,
      required this.status, required this.statusColor, required this.statusBg, required this.deadline});
}

class _ProjectCard extends StatelessWidget {
  final _ProjectData data;
  final bool isId;
  const _ProjectCard({required this.data, required this.isId});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 12, offset: const Offset(0, 4))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Title + status badge
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(child: Text(data.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: FPal.ink, height: 1.2))),
          const SizedBox(width: 10),
          Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(color: data.statusBg, borderRadius: BorderRadius.circular(8)),
              child: Text(data.status, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: data.statusColor))),
        ]),
        const SizedBox(height: 10),
        // Client
        Text('${isId ? "Klien" : "Client"}: ${data.client}',
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: FPal.inkMuted)),
        const SizedBox(height: 14),
        // Progress
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(isId ? 'Penyelesaian' : 'Completion',
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: FPal.primary)),
          Text('${(data.progress * 100).toInt()}%',
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: FPal.ink)),
        ]),
        const SizedBox(height: 8),
        _AnimProgressBar(value: data.progress),
        const SizedBox(height: 10),
        // Deadline
        Row(children: [
          Icon(data.deadline.contains('segera') ? Icons.info_outline_rounded : Icons.calendar_today_rounded,
              color: FPal.inkMuted, size: 14),
          const SizedBox(width: 6),
          Text(data.deadline, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: FPal.inkMuted)),
        ]),
      ]),
    );
  }
}

class _AnimProgressBar extends StatefulWidget {
  final double value;
  const _AnimProgressBar({required this.value});
  @override
  State<_AnimProgressBar> createState() => _AnimProgressBarState();
}

class _AnimProgressBarState extends State<_AnimProgressBar> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final Animation<double> _a;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000));
    _a = Tween<double>(begin: 0, end: widget.value).animate(CurvedAnimation(parent: _c, curve: Curves.easeOutCubic));
    Future.delayed(const Duration(milliseconds: 400), () { if (mounted) _c.forward(); });
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(animation: _a, builder: (_, __) => Container(
      height: 8, decoration: BoxDecoration(color: const Color(0xFFE8E5E0), borderRadius: BorderRadius.circular(4)),
      child: FractionallySizedBox(alignment: Alignment.centerLeft, widthFactor: _a.value.clamp(0, 1),
          child: Container(decoration: BoxDecoration(color: FPal.primary, borderRadius: BorderRadius.circular(4)))),
    ));
  }
}

class _ActivityData {
  final String category, text, time;
  final List<String> boldParts;
  final Color catColor, dotColor;
  const _ActivityData({required this.category, required this.catColor, required this.text,
      required this.boldParts, required this.time, required this.dotColor});
}

class _ActivityItem extends StatelessWidget {
  final _ActivityData data;
  final bool isLast;
  const _ActivityItem({required this.data, this.isLast = false});

  @override
  Widget build(BuildContext context) {
    return IntrinsicHeight(child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // Timeline dot + line
      Column(children: [
        Container(width: 12, height: 12, decoration: BoxDecoration(shape: BoxShape.circle, color: data.dotColor)),
        if (!isLast) Expanded(child: Container(width: 2, margin: const EdgeInsets.symmetric(vertical: 4),
            color: const Color(0xFFE8E5E0))),
      ]),
      const SizedBox(width: 16),
      // Content card
      Expanded(child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8, offset: const Offset(0, 2))]),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Category label
          Text(data.category, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: data.catColor)),
          const SizedBox(height: 6),
          // Rich text with bold parts
          _buildRichText(),
          const SizedBox(height: 6),
          Text(data.time, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: FPal.inkMuted, fontStyle: FontStyle.italic)),
        ]),
      )),
    ]));
  }

  Widget _buildRichText() {
    String remaining = data.text;
    final spans = <TextSpan>[];
    for (final bold in data.boldParts) {
      final idx = remaining.indexOf(bold);
      if (idx >= 0) {
        if (idx > 0) spans.add(TextSpan(text: remaining.substring(0, idx)));
        spans.add(TextSpan(text: bold, style: const TextStyle(fontWeight: FontWeight.w800)));
        remaining = remaining.substring(idx + bold.length);
      }
    }
    if (remaining.isNotEmpty) spans.add(TextSpan(text: remaining));
    return Text.rich(TextSpan(style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: FPal.ink, height: 1.4), children: spans));
  }
}
