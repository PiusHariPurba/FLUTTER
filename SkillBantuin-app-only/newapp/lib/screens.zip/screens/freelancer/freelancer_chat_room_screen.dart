import 'package:flutter/material.dart';
import '../../widgets/app_theme.dart';
import '../../widgets/app_animations.dart';

/// Chat Room Screen Freelancer — percakapan private dengan klien.
/// Bubbles, project card link, input bar. Design: pic 6
class FreelancerChatRoomScreen extends StatefulWidget {
  final String name;
  final bool isOnline;
  final Color avatarColor;
  const FreelancerChatRoomScreen({super.key, required this.name, required this.isOnline, required this.avatarColor});
  @override
  State<FreelancerChatRoomScreen> createState() => _FreelancerChatRoomScreenState();
}

class _FreelancerChatRoomScreenState extends State<FreelancerChatRoomScreen> {
  final _msgCtrl = TextEditingController();

  List<_Msg> get _messages => const [
    _Msg(text: 'Halo, apakah revisi untuk desain landing page sudah bisa saya lihat?',
        isMe: false, time: '10:45 AM'),
    _Msg(text: 'Halo Pak Andi, sedang saya proses penyelesaiannya. Estimasi 1 jam lagi saya kirim ya.',
        isMe: true, time: '10:47 AM', isRead: true),
    _Msg(text: 'Baik, ditunggu ya.', isMe: false, time: '10:50 AM'),
    // Project card link
    _Msg(text: '', isMe: false, time: '', isProjectCard: true,
        projectTitle: 'Current Project', projectSub: 'Landing Page Redesign v2.4'),
  ];

  @override
  void dispose() { _msgCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FPal.bg,
      appBar: AppBar(
        backgroundColor: Colors.white, elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back_rounded, color: FPal.ink),
            onPressed: () => Navigator.pop(context)),
        titleSpacing: 0,
        title: Row(children: [
          Stack(children: [
            Container(width: 38, height: 38, decoration: BoxDecoration(shape: BoxShape.circle,
                color: widget.avatarColor.withOpacity(0.12),
                border: Border.all(color: widget.avatarColor.withOpacity(0.25))),
                child: Icon(Icons.person, color: widget.avatarColor, size: 20)),
            if (widget.isOnline) Positioned(bottom: 1, left: 1,
                child: Container(width: 10, height: 10, decoration: BoxDecoration(shape: BoxShape.circle,
                    color: FPal.success, border: Border.all(color: Colors.white, width: 2)))),
          ]),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: FPal.ink)),
            if (widget.isOnline) const Text('Online',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: FPal.success)),
          ]),
        ]),
        actions: [
          IconButton(icon: const Icon(Icons.more_vert_rounded, color: FPal.ink, size: 22), onPressed: () {}),
          const SizedBox(width: 4),
        ],
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1),
            child: Container(height: 1, color: const Color(0xFFEEECE8))),
      ),

      body: Column(children: [
        // Messages
        Expanded(child: AnimatedPage(child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 10),
          children: [
            // "Today" divider
            Center(child: Container(margin: const EdgeInsets.only(bottom: 20),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: BoxDecoration(color: const Color(0xFFEEECE8), borderRadius: BorderRadius.circular(12)),
                child: const Text('Today', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: FPal.inkMuted)))),
            // Messages
            ...List.generate(_messages.length, (i) => AnimatedItem(index: i, delayMs: 80,
                child: _MsgBubble(msg: _messages[i]))),
          ],
        ))),

        // Input bar
        _InputBar(controller: _msgCtrl, onSend: () { if (_msgCtrl.text.trim().isEmpty) return; _msgCtrl.clear(); }),
      ]),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
class _Msg {
  final String text, time;
  final bool isMe, isRead, isProjectCard;
  final String? projectTitle, projectSub;
  const _Msg({required this.text, required this.isMe, required this.time,
      this.isRead = false, this.isProjectCard = false, this.projectTitle, this.projectSub});
}

class _MsgBubble extends StatelessWidget {
  final _Msg msg;
  const _MsgBubble({required this.msg});

  @override
  Widget build(BuildContext context) {
    // Project card — special widget
    if (msg.isProjectCard) return _buildProjectCard(context);

    final alignment = msg.isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start;
    final bubbleColor = msg.isMe ? FPal.primary : const Color(0xFFF0EDE8);
    final textColor = msg.isMe ? Colors.white : FPal.ink;

    return Padding(padding: const EdgeInsets.only(bottom: 4),
      child: Column(crossAxisAlignment: alignment, children: [
        Container(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(color: bubbleColor,
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(16), topRight: const Radius.circular(16),
                bottomLeft: Radius.circular(msg.isMe ? 16 : 4),
                bottomRight: Radius.circular(msg.isMe ? 4 : 16))),
          child: Text(msg.text, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500,
              color: textColor, height: 1.45)),
        ),
        Padding(padding: const EdgeInsets.only(top: 4, bottom: 10),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Text(msg.time, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: FPal.inkMuted)),
            if (msg.isMe && msg.isRead) ...[
              const SizedBox(width: 4),
              Icon(Icons.done_all_rounded, size: 14, color: FPal.primary),
            ],
          ])),
      ]));
  }

  Widget _buildProjectCard(BuildContext context) {
    return Padding(padding: const EdgeInsets.only(bottom: 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFDDE2EE)),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8, offset: const Offset(0, 2))]),
          child: Row(children: [
            Container(width: 40, height: 40,
                decoration: BoxDecoration(color: FPal.primaryLight, borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.description_rounded, color: FPal.primary, size: 20)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(msg.projectTitle ?? '', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: FPal.primary)),
              const SizedBox(height: 2),
              Text(msg.projectSub ?? '', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: FPal.inkMuted)),
            ])),
            const Icon(Icons.chevron_right_rounded, color: FPal.inkMuted, size: 22),
          ]),
        ),
      ]));
  }
}

class _InputBar extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onSend;
  const _InputBar({required this.controller, required this.onSend});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: BoxDecoration(color: Colors.white,
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, -2))]),
      child: SafeArea(top: false, child: Row(children: [
        // Attachment
        const Icon(Icons.attach_file_rounded, color: FPal.inkMuted, size: 22),
        const SizedBox(width: 10),
        // Text field
        Expanded(child: Container(height: 44, padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(color: FPal.bgMuted, borderRadius: BorderRadius.circular(22)),
            child: Row(children: [
              Expanded(child: TextField(controller: controller,
                  decoration: const InputDecoration(hintText: 'Tulis pesan...',
                      hintStyle: TextStyle(color: FPal.inkMuted, fontSize: 14, fontWeight: FontWeight.w500),
                      border: InputBorder.none, isDense: true, contentPadding: EdgeInsets.zero),
                  style: const TextStyle(fontSize: 14, color: FPal.ink))),
              const Icon(Icons.add_circle_outline_rounded, color: FPal.inkMuted, size: 20),
            ]))),
        const SizedBox(width: 10),
        // Send
        GestureDetector(onTap: onSend,
            child: Container(width: 44, height: 44, decoration: BoxDecoration(shape: BoxShape.circle, color: FPal.primary,
                boxShadow: [BoxShadow(color: FPal.primary.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 2))]),
                child: const Icon(Icons.send_rounded, color: Colors.white, size: 20))),
      ])),
    );
  }
}
