import 'package:flutter/material.dart';
import '../models/auth_flow_mode.dart';
import '../models/user_role.dart';
import '../services/auth_service.dart';
import '../widgets/app_theme.dart';
import '../widgets/auth_flow_widgets.dart';
import 'client/client_navigation_screen.dart';
import 'freelancer/freelancer_navigation_screen.dart';
import 'role_selection_screen.dart';

class RegisterScreen extends StatefulWidget {
  final UserRole selectedRole;
  const RegisterScreen({super.key, required this.selectedRole});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _usernameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  final _auth = AuthService();

  // ── FIX: tambah state _agreeTerms ──────────────────────────────────────────
  bool _obscure = true,
      _obscureConfirm = true,
      _keepSignedIn = true,
      _loading = false,
      _agreeTerms = false; // ← BARU

  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeIn,
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _usernameCtrl.dispose();
    _phoneCtrl.dispose();
    _passCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;

    // ── FIX: validasi terms sebelum submit ─────────────────────────────────
    if (!_agreeTerms) {
      _snack('Anda harus menyetujui syarat & ketentuan.');
      return;
    }

    setState(() => _loading = true);
    try {
      final res = await _auth.register(
        name: _nameCtrl.text,
        email: _emailCtrl.text,
        password: _passCtrl.text,
        passwordConfirmation: _passCtrl.text,
        role: widget.selectedRole.name,
        username: _usernameCtrl.text.isNotEmpty ? _usernameCtrl.text : null,
        phoneNumber: _phoneCtrl.text.isNotEmpty ? _phoneCtrl.text : null,
      );
      if (!mounted) return;
      if (!res.success) {
        _snack(res.message ?? 'Registrasi gagal.');
        return;
      }
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(
            builder: (_) => widget.selectedRole == UserRole.client
                ? const ClientNavigationScreen()
                : const FreelancerNavigationScreen()),
        (r) => false,
      );
    } on AuthException catch (e) {
      _snack(e.message);
    } catch (_) {
      _snack('Terjadi kendala saat mendaftar.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final sp = authVerticalSpacing(context);
    return Scaffold(
      body: AuthGradientBackground(
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: AuthContentContainer(
              scrollable: true,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: sp * 0.3),
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.arrow_back_rounded,
                            color: Colors.white),
                        padding: EdgeInsets.zero,
                      ),
                      const SizedBox(width: 4),
                      const BrandMark(size: 38, dark: true),
                    ],
                  ),
                  SizedBox(height: sp * 0.6),
                  Text(
                    widget.selectedRole == UserRole.client
                        ? 'Daftar sebagai\nClient'
                        : 'Daftar sebagai\nFreelancer',
                    style: const TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        height: 1.1,
                        letterSpacing: -0.3),
                  ),
                  SizedBox(height: sp * 0.7),
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black.withValues(alpha: 0.1),
                            blurRadius: 32,
                            offset: const Offset(0, 16))
                      ],
                    ),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          _field(_nameCtrl, 'Nama Lengkap',
                              Icons.person_outline_rounded,
                              validator: (v) =>
                                  (v == null || v.trim().isEmpty)
                                      ? 'Wajib diisi'
                                      : null),
                          const SizedBox(height: 14),
                          _field(_emailCtrl, 'Email',
                              Icons.email_outlined, validator: (v) {
                            if (v == null || v.trim().isEmpty)
                              return 'Wajib diisi';
                            if (!v.contains('@'))
                              return 'Format email tidak valid';
                            return null;
                          }),
                          const SizedBox(height: 14),
                          _field(_usernameCtrl, 'Username',
                              Icons.alternate_email_rounded,
                              validator: (v) {
                            if (v == null || v.trim().isEmpty)
                              return 'Wajib diisi';
                            if (v.trim().length < 4)
                              return 'Minimal 4 karakter';
                            return null;
                          }),
                          const SizedBox(height: 14),
                          _field(_phoneCtrl, 'Nomor HP',
                              Icons.phone_outlined,
                              keyboard: TextInputType.phone,
                              validator: (v) {
                            if (v == null || v.trim().isEmpty)
                              return 'Wajib diisi';
                            if (v.trim().length < 10)
                              return 'Minimal 10 digit';
                            return null;
                          }),
                          const SizedBox(height: 14),
                          TextFormField(
                            controller: _passCtrl,
                            obscureText: _obscure,
                            decoration: InputDecoration(
                              labelText: 'Password',
                              prefixIcon: const Icon(
                                  Icons.lock_outline_rounded,
                                  size: 18),
                              suffixIcon: IconButton(
                                  icon: Icon(
                                      _obscure
                                          ? Icons.visibility_off_outlined
                                          : Icons.visibility_outlined,
                                      size: 18),
                                  onPressed: () => setState(
                                      () => _obscure = !_obscure)),
                            ),
                            validator: (v) {
                              if (v == null || v.isEmpty)
                                return 'Wajib diisi';
                              if (v.length < 6)
                                return 'Minimal 6 karakter';
                              return null;
                            },
                          ),
                          const SizedBox(height: 14),
                          TextFormField(
                            controller: _confirmCtrl,
                            obscureText: _obscureConfirm,
                            decoration: InputDecoration(
                              labelText: 'Konfirmasi Password',
                              prefixIcon: const Icon(
                                  Icons.verified_user_outlined,
                                  size: 18),
                              suffixIcon: IconButton(
                                  icon: Icon(
                                      _obscureConfirm
                                          ? Icons.visibility_off_outlined
                                          : Icons.visibility_outlined,
                                      size: 18),
                                  onPressed: () => setState(() =>
                                      _obscureConfirm =
                                          !_obscureConfirm)),
                            ),
                            validator: (v) {
                              if (v == null || v.isEmpty)
                                return 'Wajib diisi';
                              if (v != _passCtrl.text)
                                return 'Password tidak cocok';
                              return null;
                            },
                          ),
                          const SizedBox(height: 12),

                          // ── Tetap masuk ──────────────────────────────────
                          Row(
                            children: [
                              SizedBox(
                                  height: 24,
                                  child: Checkbox(
                                      value: _keepSignedIn,
                                      onChanged: (v) => setState(() =>
                                          _keepSignedIn = v ?? true),
                                      activeColor: FPal.primary,
                                      materialTapTargetSize:
                                          MaterialTapTargetSize
                                              .shrinkWrap)),
                              const SizedBox(width: 6),
                              const Text(
                                  'Tetap masuk di perangkat ini',
                                  style: TextStyle(
                                      fontSize: 13,
                                      color: FPal.inkSoft)),
                            ],
                          ),
                          const SizedBox(height: 8),

                          // ── FIX: Checkbox syarat & ketentuan ─────────────
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              SizedBox(
                                height: 24,
                                child: Checkbox(
                                  value: _agreeTerms,
                                  onChanged: (v) => setState(
                                      () => _agreeTerms = v ?? false),
                                  activeColor: FPal.primary,
                                  materialTapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                ),
                              ),
                              const SizedBox(width: 6),
                              const Expanded(
                                child: Text(
                                  'Saya menyetujui syarat & ketentuan',
                                  style: TextStyle(
                                      fontSize: 13,
                                      color: FPal.inkSoft),
                                ),
                              ),
                            ],
                          ),

                          const SizedBox(height: 20),
                          PrimaryButton(
                              label: _loading
                                  ? 'Memproses...'
                                  : 'Daftar Sekarang',
                              onPressed: _loading ? null : _register,
                              loading: _loading),
                          const SizedBox(height: 16),
                          GestureDetector(
                            onTap: () => Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                    builder: (_) =>
                                        const RoleSelectionScreen())),
                            child: const Text.rich(TextSpan(children: [
                              TextSpan(
                                  text: 'Sudah punya akun? ',
                                  style: TextStyle(
                                      color: FPal.inkSoft,
                                      fontSize: 13)),
                              TextSpan(
                                  text: 'Masuk',
                                  style: TextStyle(
                                      color: FPal.primary,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 13)),
                            ])),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _field(TextEditingController ctrl, String label, IconData icon,
      {TextInputType? keyboard,
      String? Function(String?)? validator}) {
    return TextFormField(
      controller: ctrl,
      keyboardType: keyboard,
      decoration:
          InputDecoration(labelText: label, prefixIcon: Icon(icon, size: 18)),
      validator: validator,
    );
  }
}