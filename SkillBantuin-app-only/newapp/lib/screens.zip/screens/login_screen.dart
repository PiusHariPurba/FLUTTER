import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/auth_flow_mode.dart';
import '../models/user_role.dart';
import '../providers/providers.dart';
import '../widgets/app_theme.dart';
import '../widgets/auth_flow_widgets.dart';
import 'client/client_navigation_screen.dart';
import 'freelancer/freelancer_navigation_screen.dart';
import 'role_selection_screen.dart';

class LoginScreen extends StatefulWidget {
  final UserRole selectedRole;
  const LoginScreen({super.key, required this.selectedRole});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _rememberMe = false, _obscure = true;

  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();
    _fadeAnimation =
        CurvedAnimation(parent: _fadeController, curve: Curves.easeIn);
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    final auth = context.read<AuthProvider>();
    final success = await auth.login(
      identity: _emailCtrl.text.trim(),
      password: _passCtrl.text,
      role: widget.selectedRole.name,
    );

    if (!mounted) return;

    if (success) {
      // Load role-specific data setelah login berhasil
      if (widget.selectedRole == UserRole.client) {
        context.read<TaskProvider>().loadTasks();
      } else {
        context.read<FreelancerProvider>().loadFreelancers();
      }
      context.read<ChatProvider>().loadChats(
        myUserId: auth.user?.id ?? '',
        myRole: widget.selectedRole.name,
      );

      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(
            builder: (_) => widget.selectedRole == UserRole.client
                ? const ClientNavigationScreen()
                : const FreelancerNavigationScreen()),
        (r) => false,
      );
    } else {
      _snack(auth.error ?? 'Login gagal. Coba lagi.');
      auth.clearError();
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final isLoading = context.watch<AuthProvider>().isLoading;
    final isClient = widget.selectedRole == UserRole.client;
    final sp = authVerticalSpacing(context);

    return Scaffold(
      body: AuthGradientBackground(
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: AuthContentContainer(
              scrollable: true,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: sp * 0.3),
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.arrow_back_rounded,
                            color: Colors.white),
                        padding: EdgeInsets.zero,
                      ),
                      const SizedBox(width: 4),
                      const BrandMark(size: 38, dark: true),
                    ],
                  ),
                  SizedBox(height: sp * 0.6),
                  const Text(
                    'Selamat\ndatang kembali',
                    style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        height: 1.1,
                        letterSpacing: -0.3),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    isClient
                        ? 'Login sebagai Client'
                        : 'Login sebagai Freelancer',
                    style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.65),
                        fontSize: 14),
                  ),
                  const SizedBox(height: 12),
                  // Demo credentials hint
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 11),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.07),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: Colors.white.withValues(alpha: 0.12)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.info_outline_rounded,
                            size: 15,
                            color: Colors.white.withValues(alpha: 0.7)),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            isClient
                                ? 'Demo: clientdemo / demo123'
                                : 'Demo: freelancerdemo / demo123',
                            style: TextStyle(
                                fontSize: 12,
                                color: Colors.white.withValues(alpha: 0.7)),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: sp * 0.8),
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black.withValues(alpha: 0.1),
                            blurRadius: 32,
                            offset: const Offset(0, 16)),
                      ],
                    ),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          TextFormField(
                            controller: _emailCtrl,
                            decoration: const InputDecoration(
                              labelText: 'Username atau Email',
                              prefixIcon: Icon(
                                  Icons.alternate_email_rounded,
                                  size: 18),
                            ),
                            validator: (v) =>
                                (v == null || v.isEmpty)
                                    ? 'Wajib diisi'
                                    : null,
                          ),
                          const SizedBox(height: 14),
                          TextFormField(
                            controller: _passCtrl,
                            obscureText: _obscure,
                            decoration: InputDecoration(
                              labelText: 'Password',
                              prefixIcon: const Icon(
                                  Icons.lock_outline_rounded,
                                  size: 18),
                              suffixIcon: IconButton(
                                icon: Icon(
                                    _obscure
                                        ? Icons.visibility_off_outlined
                                        : Icons.visibility_outlined,
                                    size: 18),
                                onPressed: () =>
                                    setState(() => _obscure = !_obscure),
                              ),
                            ),
                            validator: (v) {
                              if (v == null || v.isEmpty) return 'Wajib diisi';
                              if (v.length < 6) return 'Minimal 6 karakter';
                              return null;
                            },
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              SizedBox(
                                height: 24,
                                child: Checkbox(
                                  value: _rememberMe,
                                  onChanged: (v) => setState(
                                      () => _rememberMe = v ?? false),
                                  activeColor: FPal.primary,
                                  materialTapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                ),
                              ),
                              const SizedBox(width: 6),
                              const Text('Ingat saya',
                                  style: TextStyle(
                                      fontSize: 13, color: FPal.inkSoft)),
                            ],
                          ),
                          const SizedBox(height: 18),
                          PrimaryButton(
                              label: isLoading ? 'Memproses...' : 'Masuk',
                              onPressed: isLoading ? null : _login,
                              loading: isLoading),
                          const SizedBox(height: 18),
                          Center(
                            child: GestureDetector(
                              onTap: () => Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        const RoleSelectionScreen(
                                            mode: AuthFlowMode.register),
                                  )),
                              child: Text.rich(
                                TextSpan(children: [
                                  const TextSpan(
                                      text: 'Belum punya akun? ',
                                      style: TextStyle(
                                          color: FPal.inkSoft,
                                          fontSize: 13)),
                                  const TextSpan(
                                      text: 'Daftar',
                                      style: TextStyle(
                                          color: FPal.primary,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 13)),
                                ]),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
