import 'dart:async';
import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../models/chat_models.dart';
import '../../models/user_role.dart';
import '../../providers/providers.dart';
import '../../utils/task_ui_utils.dart';
import '../../widgets/app_theme.dart';
import '../../widgets/app_animations.dart';
import '../../widgets/status_badge.dart';

class ChatRoomScreen extends StatefulWidget {
  final ChatRoom room;
  final UserRole currentRole;

  const ChatRoomScreen({
    super.key,
    required this.room,
    required this.currentRole,
  });

  @override
  State<ChatRoomScreen> createState() => _ChatRoomScreenState();
}

class _ChatRoomScreenState extends State<ChatRoomScreen> {
  final _messageController = TextEditingController();
  Timer? _pollTimer;

  @override
  void initState() {
    super.initState();
    // Load fresh messages dari server saat screen dibuka
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadAndPoll();
    });
  }

  void _loadAndPoll() {
    final chatProvider = context.read<ChatProvider>();
    chatProvider.loadMessages(widget.room.id);
    chatProvider.markRoomAsRead(widget.room.id);
    // Poll setiap 5 detik
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted) chatProvider.loadMessages(widget.room.id);
    });
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _messageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final currentParty = widget.currentRole == UserRole.client
        ? ChatPartyRole.client
        : ChatPartyRole.freelancer;
    // Use ChatProvider as single source of truth for messages
    final chatProvider = context.watch<ChatProvider>();
    final liveRoom = chatProvider.getRoomById(widget.room.id);
    final messages = liveRoom?.messages ?? widget.room.messages;

    return Scaffold(
      backgroundColor: Pal.bg,
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(
          children: [
            CircleAvatar(
              radius: 20,
              backgroundColor: Pal.accentLight,
              child: Icon(Icons.person_rounded, color: Pal.accent, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    widget.room.counterpartName,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                  ),
                  Text(
                    widget.room.taskTitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 12, color: Pal.inkSoft),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
            decoration: BoxDecoration(
              color: Pal.bgMuted,
              border: const Border(
                bottom: BorderSide(color: Color(0xFFE6E4E0)),
              ),
            ),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                StatusBadge(
                  label: taskStatusLabel(widget.room.taskStatus),
                  color: taskStatusColor(widget.room.taskStatus),
                ),
                _MiniChip(label: widget.room.counterpartRoleLabel),
                _MiniChip(label: widget.room.taskTitle),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final message = messages[index];
                final isMine = message.sender == currentParty;

                if (message.type == ChatMessageType.negotiation &&
                    message.negotiation != null) {
                  return AnimatedItem(
                    index: index,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: _NegotiationCard(
                        isMine: isMine,
                        message: message,
                        onActionTap: (action) => _handleNegotiationAction(action),
                      ),
                    ),
                  );
                }

                return AnimatedItem(
                  index: index,
                  child: Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Align(
                    alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 290),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: isMine ? Pal.accent : Colors.white,
                          borderRadius: BorderRadius.circular(18),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF1A1918).withValues(alpha: 0.05),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              message.content,
                              style: TextStyle(
                                color: isMine ? Colors.white : Pal.ink,
                                height: 1.5,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '${message.timeLabel} · ${_chatStatusLabel(message.status)}',
                              style: TextStyle(
                                fontSize: 11,
                                color: isMine
                                    ? Colors.white.withValues(alpha: 0.7)
                                    : Pal.inkMuted,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Container(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(top: BorderSide(color: Color(0xFFE6E4E0))),
              ),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Lampiran akan dilanjutkan di tahap berikutnya.')),
                    ),
                    icon: const Icon(Icons.attach_file_rounded),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _messageController,
                      decoration: const InputDecoration(hintText: 'Tulis pesan...'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  CircleAvatar(
                    radius: 22,
                    backgroundColor: Pal.accent,
                    child: IconButton(
                      onPressed: () => _sendMessage(currentParty),
                      icon: const Icon(Icons.send_rounded, color: Colors.white, size: 18),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _sendMessage(ChatPartyRole currentParty) {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;
    // Persist message into ChatProvider (stays alive across screen pops)
    context.read<ChatProvider>().sendMessage(
      roomId: widget.room.id,
      content: text,
      senderRole: currentParty,
    );
    _messageController.clear();
  }

  void _handleNegotiationAction(String action) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Aksi negosiasi "$action" dipicu untuk demo.')),
    );
  }

  String _chatStatusLabel(ChatStatus status) {
    switch (status) {
      case ChatStatus.sent: return 'sent';
      case ChatStatus.read: return 'read';
      case ChatStatus.unread: return 'unread';
    }
  }
}

class _NegotiationCard extends StatelessWidget {
  final bool isMine;
  final ChatMessage message;
  final ValueChanged<String> onActionTap;

  const _NegotiationCard({
    required this.isMine,
    required this.message,
    required this.onActionTap,
  });

  Color _negotiationColor(NegotiationStatus status) {
    switch (status) {
      case NegotiationStatus.pending:   return Pal.warning;
      case NegotiationStatus.accepted:  return Pal.success;
      case NegotiationStatus.rejected:  return Pal.danger;
      case NegotiationStatus.countered: return Pal.purple;
    }
  }

  String _negotiationStatusLabel(NegotiationStatus status) {
    switch (status) {
      case NegotiationStatus.pending:   return 'Pending';
      case NegotiationStatus.accepted:  return 'Diterima';
      case NegotiationStatus.rejected:  return 'Ditolak';
      case NegotiationStatus.countered: return 'Counter';
    }
  }

  @override
  Widget build(BuildContext context) {
    final negotiation = message.negotiation!;
    final color = _negotiationColor(negotiation.status);

    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 320),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: color.withValues(alpha: 0.2)),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF1A1918).withValues(alpha: 0.04),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      negotiation.title,
                      style: TextStyle(fontWeight: FontWeight.w800, color: Pal.ink),
                    ),
                  ),
                  StatusBadge(
                    label: _negotiationStatusLabel(negotiation.status),
                    color: color,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _NegotiationRow(label: 'Reward', value: formatRupiah(negotiation.reward)),
              const SizedBox(height: 6),
              _NegotiationRow(label: 'Deadline', value: negotiation.deadline),
              const SizedBox(height: 10),
              Text(
                message.content,
                style: TextStyle(color: Pal.inkSoft, height: 1.5),
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: negotiation.actions.map((action) {
                  return action == negotiation.actions.first
                      ? ElevatedButton(onPressed: () => onActionTap(action), child: Text(action))
                      : OutlinedButton(onPressed: () => onActionTap(action), child: Text(action));
                }).toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NegotiationRow extends StatelessWidget {
  final String label, value;
  const _NegotiationRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 72,
          child: Text(label, style: TextStyle(color: Pal.inkSoft, fontWeight: FontWeight.w600)),
        ),
        Expanded(
          child: Text(value, style: TextStyle(color: Pal.ink, fontWeight: FontWeight.w800)),
        ),
      ],
    );
  }
}

class _MiniChip extends StatelessWidget {
  final String label;
  const _MiniChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Pal.accentLight,
        borderRadius: BorderRadius.circular(99),
      ),
      child: Text(
        label,
        style: TextStyle(color: Pal.accent, fontSize: 12, fontWeight: FontWeight.w700),
      ),
    );
  }
}